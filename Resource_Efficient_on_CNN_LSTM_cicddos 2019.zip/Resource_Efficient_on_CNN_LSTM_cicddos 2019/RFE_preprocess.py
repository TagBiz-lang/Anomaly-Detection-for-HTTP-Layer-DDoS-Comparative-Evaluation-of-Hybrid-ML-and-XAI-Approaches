"""
Resource-Efficient CNN-LSTM DDoS Detection Preprocessing
Based on Bamber et al. 2025 methodology

Key Features:
- Recursive Feature Elimination (RFE) for optimal feature selection
- Decision Tree-based importance ranking
- Computationally efficient preprocessing
- Reduced memory footprint
- Faster training and inference
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import torch
from torch.utils.data import TensorDataset, DataLoader
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import RFE, RFECV
from sklearn.tree import DecisionTreeClassifier
from imblearn.over_sampling import SMOTE, ADASYN
from imblearn.under_sampling import RandomUnderSampler
from collections import Counter
import json
import warnings
warnings.filterwarnings('ignore')

import os

BASE_FOLDER = os.path.dirname(os.path.abspath(__file__))


class ResourceEfficientCNNLSTMPreprocessor:
    
    def __init__(self, n_features_to_select=None, rfe_step=1,
                 variance_threshold=0.01, scaler_type='standard',
                 balance_method=None, dataset_version='2019',
                 use_rfecv=False, cv_folds=5):
        def identify_label_column(self, df):
        # Example: assume label is the last column
            return df.columns[-1]
        self.n_features_to_select = n_features_to_select
        self.rfe_step = rfe_step
        self.variance_threshold = variance_threshold
        self.scaler_type = scaler_type
        self.balance_method = balance_method
        self.dataset_version = dataset_version
        self.use_rfecv = use_rfecv
        self.cv_folds = cv_folds
        
        # Initialize scaler
        if scaler_type == 'standard':
            self.scaler = StandardScaler()
        elif scaler_type == 'robust':
            self.scaler = RobustScaler()
        else:
            from sklearn.preprocessing import MinMaxScaler
            self.scaler = MinMaxScaler()
        
        self.feature_names = None
        self.selected_features = None
        self.removed_features = []
        self.feature_importances = None
        self.rfe_selector = None
        self.preprocessing_stats = {}
        
    

    def load_dataset(self, filepath, label_col=None, sample_size=None):
        df = None
        for encoding in ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']:
            try:
                if sample_size:
                    df = pd.read_csv(filepath, encoding=encoding, nrows=sample_size)
                else:
                    df = pd.read_csv(filepath, encoding=encoding)
                print(f"Loaded dataset with {encoding} encoding")
                break
            except Exception as e:
                print(f"Failed with {encoding}: {e}")
                continue

        if df is None:
            raise ValueError(f"Could not load dataset {filepath} with any of the tried encodings.")

        print(f"Dataset shape: {df.shape}")
        return df
    

    def load_dataset(self, filepath, label_col=None, sample_size=None):
        df = None
        for encoding in ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']:
            try:
                if sample_size:
                    df = pd.read_csv(filepath, encoding=encoding, nrows=sample_size)
                else:
                    df = pd.read_csv(filepath, encoding=encoding)
                print(f"Loaded dataset with {encoding} encoding")
                break
            except Exception as e:
                print(f"Failed with {encoding}: {e}")
                continue

        if df is None:
            raise ValueError(f"Could not load dataset {filepath} with any of the tried encodings.")

        print(f"Dataset shape: {df.shape}")
        return df

    def identify_label_column(self, df):
        possible_labels = ['Label', 'label', ' Label', 'Attack', 'attack', 
                      'Class', 'class']
        for col in possible_labels:
            if col in df.columns:
                print(f"Label column detected: '{col}'")
            return col
            
        raise ValueError("Could not auto-detect label column. Please specify manually.")
    

    def clean_data(self, df, label_col):
        print("\n" + "-"*70)
        print("DATA CLEANING FOR CNN-LSTM")
    
        
        # Separate features and labels
        y = df[label_col].copy()
        X = df.drop(columns=[label_col])
        
        initial_shape = X.shape
        print(f"Initial shape: {initial_shape}")
        
        # Clean column names
        X.columns = X.columns.str.strip()
        
        # Keep only numeric columns
        numeric_cols = X.select_dtypes(include=[np.number]).columns
        X = X[numeric_cols]
        print(f"After removing non-numeric: {X.shape}")
        
        # Handle infinite values
        X.replace([np.inf, -np.inf], np.nan, inplace=True)
        
        # Handle missing values
        missing_count = X.isnull().sum().sum()
        if missing_count > 0:
            print(f"Missing values: {missing_count}")
            print("Filling with median...")
            X.fillna(X.median(), inplace=True)
        
        # Store feature names
        self.feature_names = X.columns.tolist()
        
        print(f"Cleaned shape: {X.shape}")
        
        return X, y



    
    def analyze_labels(self, y):
        """
        Analyze label distribution
        
        Args:
            y: Labels
        
        Returns:
            Label statistics
        """
        print("\n" + "="*70)
        print("LABEL DISTRIBUTION")
        print("="*70)
        
        # Get unique labels
        unique_labels = y.unique()
        print(f"Unique classes: {len(unique_labels)}")
        
        # Count distribution
        label_counts = y.value_counts()
        
        print("\nClass distribution:")
        for label, count in label_counts.items():
            percentage = (count / len(y)) * 100
            print(f"  {str(label):40s}: {count:8d} ({percentage:5.2f}%)")
        
        # Binary classification (Benign vs Attack)
        y_binary = y.apply(lambda x: 0 if 'benign' in str(x).lower() else 1)
        binary_counts = y_binary.value_counts()
        
        print("\nBinary classification:")
        print(f"  Benign (0): {binary_counts.get(0, 0):8d}")
        print(f"  Attack (1): {binary_counts.get(1, 0):8d}")
        
        imbalance_ratio = binary_counts.max() / binary_counts.min()
        print(f"\nImbalance ratio: {imbalance_ratio:.2f}")
        
        if imbalance_ratio > 10:
            print("Severe imbalance! Balancing recommended.")
        elif imbalance_ratio > 3:
            print("Moderate imbalance detected.")
        else:
            print("Classes relatively balanced.")
        
        self.preprocessing_stats['label_distribution'] = label_counts.to_dict()
        self.preprocessing_stats['imbalance_ratio'] = float(imbalance_ratio)
        
        return y_binary
    
    def remove_low_variance_features(self, X):
        """
        Remove low variance features (constant or near-constant)
        
        Args:
            X: Features DataFrame
        
        Returns:
            Filtered DataFrame
        """
        print("\n" + "="*70)
        print("LOW VARIANCE FEATURE REMOVAL")
        print("="*70)
        
        variances = X.var()
        low_var_features = variances[variances < self.variance_threshold].index.tolist()
        
        print(f"Features with variance < {self.variance_threshold}: {len(low_var_features)}")
        
        if len(low_var_features) > 0:
            print(f"Removing {len(low_var_features)} low variance features")
            self.removed_features.extend(low_var_features)
            X = X.drop(columns=low_var_features)
            print(f"Shape after removal: {X.shape}")
        else:
            print("No low variance features found")
        
        self.preprocessing_stats['removed_low_variance'] = len(low_var_features)
        
        return X
    
    def recursive_feature_elimination(self, X, y, sample_size=50000):
       
        print("\n" + "="*70)
        print("RECURSIVE FEATURE ELIMINATION (RFE)")
        print("Resource-Efficient Method ")
        print("="*70)
        
        # Sample for large datasets to speed up RFE
        if len(X) > sample_size:
            print(f"Sampling {sample_size} rows for RFE...")
            indices = np.random.choice(len(X), sample_size, replace=False)
            X_sample = X.iloc[indices]
            y_sample = y.iloc[indices]
        else:
            X_sample = X
            y_sample = y
        
        # Initialize Decision Tree estimator
        print("Initializing Decision Tree classifier...")
        dt_estimator = DecisionTreeClassifier(
            max_depth=10,
            min_samples_split=20,
            min_samples_leaf=10,
            random_state=42
        )
        
        # Determine number of features to select
        if self.n_features_to_select is None:
            if self.use_rfecv:
                print("Using RFECV (Cross-Validated RFE)...")
                print(f"Cross-validation folds: {self.cv_folds}")
                selector = RFECV(
                    estimator=dt_estimator,
                    step=self.rfe_step,
                    cv=self.cv_folds,
                    scoring='accuracy',
                    n_jobs=-1,
                    verbose=1
                )
            else:
                # Auto-select optimal number (30-50% of features)
                n_features = max(int(X.shape[1] * 0.3), 20)
                print(f"Auto-selecting {n_features} features (30% of total)")
                selector = RFE(
                    estimator=dt_estimator,
                    n_features_to_select=n_features,
                    step=self.rfe_step,
                    verbose=1
                )
        else:
            print(f"Selecting top {self.n_features_to_select} features")
            selector = RFE(
                estimator=dt_estimator,
                n_features_to_select=self.n_features_to_select,
                step=self.rfe_step,
                verbose=1
            )
        
        # Fit RFE
        print("\nRunning RFE... (this may take a few minutes)")
        selector.fit(X_sample, y_sample)
        
        # Get selected features
        selected_mask = selector.support_
        selected_features = X.columns[selected_mask].tolist()
        removed_features = X.columns[~selected_mask].tolist()
        
        # Get feature rankings
        feature_ranking = selector.ranking_
        
        # Get feature importances from the final estimator
        if hasattr(selector.estimator_, 'feature_importances_'):
            importances = selector.estimator_.feature_importances_
            feature_importance_dict = {
                feat: imp for feat, imp in zip(selected_features, importances)
            }
        else:
            feature_importance_dict = {}
        
        self.rfe_selector = selector
        self.feature_importances = feature_importance_dict
        self.removed_features.extend(removed_features)
        
        print(f"\n{'='*70}")
        print("RFE RESULTS")
        print(f"{'='*70}")
        print(f"Original features:     {X.shape[1]}")
        print(f"Selected features:     {len(selected_features)}")
        print(f"Removed features:      {len(removed_features)}")
        print(f"Reduction:             {len(removed_features)/X.shape[1]*100:.1f}%")
        
        if self.use_rfecv and hasattr(selector, 'n_features_'):
            print(f"Optimal features (CV): {selector.n_features_}")
            print(f"Best CV score:         {selector.cv_results_['mean_test_score'].max():.4f}")
        
        # Show top features by importance
        if feature_importance_dict:
            print(f"\nTop 15 most important features:")
            sorted_features = sorted(
                feature_importance_dict.items(),
                key=lambda x: x[1],
                reverse=True
            )[:15]
            for i, (feat, imp) in enumerate(sorted_features, 1):
                print(f"{i:2d}. {feat:40s}: {imp:.6f}")
        
        self.preprocessing_stats['rfe_method'] = 'RFECV' if self.use_rfecv else 'RFE'
        self.preprocessing_stats['selected_features_count'] = len(selected_features)
        self.preprocessing_stats['removed_features_count'] = len(removed_features)
        self.preprocessing_stats['feature_reduction_percent'] = len(removed_features)/X.shape[1]*100
        
        return selected_features, feature_importance_dict
    
    def normalize_features(self, X_train, X_val=None, X_test=None):
        """
        Normalize features for deep learning (CRITICAL for CNN-LSTM)
        
        Args:
            X_train: Training features
            X_val: Validation features (optional)
            X_test: Test features (optional)
        
        Returns:
            Normalized DataFrames
        """
        print("\n" + "="*70)
        print(f"FEATURE NORMALIZATION ({self.scaler_type.upper()})")
        print("="*70)
        
        # Fit scaler on training data only
        print("Fitting scaler on training data...")
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_train_scaled = pd.DataFrame(X_train_scaled, columns=X_train.columns, 
                                      index=X_train.index)
        
        result = [X_train_scaled]
        
        if X_val is not None:
            print("Transforming validation data...")
            X_val_scaled = self.scaler.transform(X_val)
            X_val_scaled = pd.DataFrame(X_val_scaled, columns=X_val.columns, 
                                       index=X_val.index)
            result.append(X_val_scaled)
        
        if X_test is not None:
            print("Transforming test data...")
            X_test_scaled = self.scaler.transform(X_test)
            X_test_scaled = pd.DataFrame(X_test_scaled, columns=X_test.columns, 
                                         index=X_test.index)
            result.append(X_test_scaled)
        
        print("Normalization complete")
        
        return result if len(result) > 1 else result[0]
    
    def balance_dataset(self, X, y):
        """
        Balance dataset using specified method
        
        Args:
            X: Features
            y: Labels
        
        Returns:
            Balanced X, y
        """
        if self.balance_method is None:
            return X, y
        
        print("\n" + "="*70)
        print(f"CLASS BALANCING ({self.balance_method.upper()})")
        print("="*70)
        
        print(f"Original distribution: {Counter(y)}")
        
        if self.balance_method == 'smote':
            sampler = SMOTE(random_state=42)
            X_balanced, y_balanced = sampler.fit_resample(X, y)
        
        elif self.balance_method == 'adasyn':
            sampler = ADASYN(random_state=42)
            X_balanced, y_balanced = sampler.fit_resample(X, y)
        
        elif self.balance_method == 'undersample':
            sampler = RandomUnderSampler(random_state=42)
            X_balanced, y_balanced = sampler.fit_resample(X, y)
        
        elif self.balance_method == 'hybrid':
            # Undersample majority, then SMOTE minority
            rus = RandomUnderSampler(sampling_strategy=0.5, random_state=42)
            X_temp, y_temp = rus.fit_resample(X, y)
            smote = SMOTE(random_state=42)
            X_balanced, y_balanced = smote.fit_resample(X_temp, y_temp)
        
        else:
            raise ValueError(f"Unknown balance method: {self.balance_method}")
        
        print(f"Balanced distribution: {Counter(y_balanced)}")
        print(f"Shape change: {X.shape} -> {X_balanced.shape}")
        
        self.preprocessing_stats['balance_method'] = self.balance_method
        self.preprocessing_stats['balanced_distribution'] = dict(Counter(y_balanced))
        
        return X_balanced, y_balanced
    
    def create_pytorch_datasets(self, X_train, y_train, X_val, y_val, 
                               X_test, y_test, batch_size=256):
        """
        Create PyTorch DataLoaders for CNN-LSTM
        
        Args:
            X_train, y_train: Training data
            X_val, y_val: Validation data
            X_test, y_test: Test data
            batch_size: Batch size
        
        Returns:
            train_loader, val_loader, test_tensors
        """
        print("\n" + "="*70)
        print("CREATING PYTORCH DATALOADERS")
        print("="*70)
        
        # Convert to tensors
        X_train_tensor = torch.FloatTensor(X_train.values)
        y_train_tensor = torch.LongTensor(y_train.values)
        
        X_val_tensor = torch.FloatTensor(X_val.values)
        y_val_tensor = torch.LongTensor(y_val.values)
        
        X_test_tensor = torch.FloatTensor(X_test.values)
        y_test_tensor = torch.LongTensor(y_test.values)
        
        # Create datasets
        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
        
        # Create dataloaders
        train_loader = DataLoader(train_dataset, batch_size=batch_size, 
                                 shuffle=True, num_workers=0)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, 
                               shuffle=False, num_workers=0)
        
        print(f"Train loader: {len(train_loader)} batches")
        print(f"Val loader: {len(val_loader)} batches")
        print(f"Test tensors: {X_test_tensor.shape}")
        print(f"\nDataLoaders created successfully")
        
        return train_loader, val_loader, X_test_tensor, y_test_tensor
    
    def visualize_feature_importance(self, top_n=30, 
                                    save_path=None):
       
        if not self.feature_importances:
            print("Feature importances not available")
            return
        
        if save_path is None:
            save_path = os.path.join(BASE_FOLDER, 'rfe_feature_importance.png')

        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Saved to {save_path}")   
        
        print(f"\nGenerating feature importance plot...")
        
        # Sort features by importance
        sorted_features = sorted(
            self.feature_importances.items(),
            key=lambda x: x[1],
            reverse=True
        )[:top_n]
        
        features = [f[0] for f in sorted_features]
        importances = [f[1] for f in sorted_features]
        
        # Plot
        plt.figure(figsize=(14, 10))
        colors = plt.cm.viridis(np.linspace(0, 1, len(features)))
        plt.barh(range(len(features)), importances, color=colors)
        plt.yticks(range(len(features)), features, fontsize=9)
        plt.xlabel('Feature Importance', fontsize=12, fontweight='bold')
        plt.ylabel('Features', fontsize=12, fontweight='bold')
        plt.title(f'Top {top_n} Features - RFE with Decision Tree\n'
                 f'Resource-Efficient CNN-LSTM ', 
                 fontsize=14, fontweight='bold')
        plt.gca().invert_yaxis()
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"Saved to {save_path}")
        plt.close()
    
    def preprocess_for_cnn_lstm(self, filepath, label_col=None, 
                                test_size=0.2, val_size=0.1,
                                remove_low_variance=True,
                                balance_train=False, batch_size=256,
                                visualize=True, rfe_sample_size=50000):
        """
        Complete resource-efficient preprocessing pipeline for CNN-LSTM
        
        Args:
            filepath: Dataset path
            label_col: Label column name
            test_size: Test set proportion
            val_size: Validation set proportion
            remove_low_variance: Remove low variance features
            balance_train: Balance training set
            batch_size: Batch size for DataLoaders
            visualize: Generate visualizations
            rfe_sample_size: Sample size for RFE
        
        Returns:
            train_loader, val_loader, X_test_tensor, y_test_tensor, info
        """
        print("="*70)
        print("RESOURCE-EFFICIENT CNN-LSTM PREPROCESSING PIPELINE")
        print("Based on: Bamber et al. 2025, Computers & Security")
        print("="*70)
        
        # Step 1: Load data
        df = self.load_dataset(filepath)
        
        # Step 2: Identify label column
        if label_col is None:
            label_col = self.identify_label_column(df)
        
        # Step 3: Clean data
        X, y = self.clean_data(df, label_col)
        self.preprocessing_stats['original_shape'] = X.shape
        
        # Step 4: Analyze and convert labels to binary
        y_binary = self.analyze_labels(y)
        
        # Step 5: Remove low variance features
        if remove_low_variance:
            X = self.remove_low_variance_features(X)
        
        # Step 6: Recursive Feature Elimination (RFE) - RESOURCE-EFFICIENT
        print("\n⚡ Applying Resource-Efficient Feature Selection...")
        selected_features, feature_importances = self.recursive_feature_elimination(
            X, y_binary, sample_size=rfe_sample_size
        )
        
        # Apply feature selection
        X = X[selected_features]
        self.selected_features = selected_features
        
        # Step 7: Feature selection summary
        print(f"\n{'='*70}")
        print(f"RESOURCE-EFFICIENT FEATURE SELECTION SUMMARY")
        print(f"{'='*70}")
        print(f"Original features:     {self.preprocessing_stats['original_shape'][1]}")
        print(f"Selected features:     {len(self.selected_features)}")
        print(f"Removed features:      {len(self.removed_features)}")
        print(f"Reduction:             {len(self.removed_features)/self.preprocessing_stats['original_shape'][1]*100:.1f}%")
        print(f"Memory savings:        ~{len(self.removed_features)/self.preprocessing_stats['original_shape'][1]*100:.1f}%")
        print(f"Training speedup:      ~{1/(len(self.selected_features)/self.preprocessing_stats['original_shape'][1]):.2f}x faster")
        print(f"{'='*70}")
        
        # Step 8: Split data
        print(f"\nSplitting data: train={1-test_size-val_size:.1%}, "
              f"val={val_size:.1%}, test={test_size:.1%}")
        
        X_temp, X_test, y_temp, y_test = train_test_split(
            X, y_binary, test_size=test_size, random_state=42, stratify=y_binary
        )
        
        X_train, X_val, y_train, y_val = train_test_split(
            X_temp, y_temp, test_size=val_size/(1-test_size), 
            random_state=42, stratify=y_temp
        )
        
        print(f"Train: {X_train.shape}, Val: {X_val.shape}, Test: {X_test.shape}")
        
        # Step 9: Balance training set (optional)
        if balance_train:
            X_train, y_train = self.balance_dataset(X_train, y_train)
        
        # Step 10: Normalize features (CRITICAL for deep learning)
        X_train_scaled, X_val_scaled, X_test_scaled = self.normalize_features(
            X_train, X_val, X_test
        )
        
        # Step 11: Create PyTorch DataLoaders
        train_loader, val_loader, X_test_tensor, y_test_tensor = \
            self.create_pytorch_datasets(
                X_train_scaled, y_train,
                X_val_scaled, y_val,
                X_test_scaled, y_test,
                batch_size=batch_size
            )
        
        # Step 12: Visualizations
        if visualize:
            self.visualize_feature_importance(
                top_n=min(30, len(self.selected_features))
            )
        
        # Prepare info dictionary
        info = {
            'preprocessing_stats': self.preprocessing_stats,
            'selected_features': self.selected_features,
            'removed_features': self.removed_features,
            'feature_importances': self.feature_importances,
            'scaler_type': self.scaler_type,
            'rfe_method': 'RFECV' if self.use_rfecv else 'RFE',
            'n_features_selected': len(self.selected_features),
            'train_shape': X_train_scaled.shape,
            'val_shape': X_val_scaled.shape,
            'test_shape': X_test_scaled.shape
        }
        
        print("\n" + "="*70)
        print("✅ PREPROCESSING COMPLETE - READY FOR CNN-LSTM")
        print("Resource-Efficient Method Applied")
        print("="*70)
        
        return train_loader, val_loader, X_test_tensor, y_test_tensor, info
    
    def save_preprocessing_artifacts(self, info, prefix='rfe_cnn_lstm'):
        output_folder = BASE_FOLDER
        # Save selected features
        with open(os.path.join(output_folder, f'{prefix}_selected_features.txt'), 'w') as f:
            for feat in self.selected_features:
                f.write(f"{feat}\n")
        print(f"Saved selected features to {prefix}_selected_features.txt")
        
        # Save feature importances
        if self.feature_importances:
            with open(f'{prefix}_feature_importances.txt', 'w') as f:
                sorted_features = sorted(
                    self.feature_importances.items(),
                    key=lambda x: x[1],
                    reverse=True
                )
                for feat, imp in sorted_features:
                    f.write(f"{feat}\t{imp:.6f}\n")
            print(f"Saved feature importances to {prefix}_feature_importances.txt")
        
        # Save preprocessing info
        info_serializable = {}
        for k, v in info.items():
            if isinstance(v, (pd.DataFrame, np.ndarray)):
                continue
            elif isinstance(v, dict) and any(isinstance(val, float) for val in v.values()):
                # Convert numpy floats to Python floats
                info_serializable[k] = {
                    key: float(val) if isinstance(val, (np.floating, float)) else val
                    for key, val in v.items()
                }
            else:
                info_serializable[k] = v
        
        with open(f'{prefix}_preprocessing_info.json', 'w') as f:
            json.dump(info_serializable, f, indent=2)
        print(f"Saved preprocessing info to {prefix}_preprocessing_info.json")
        
        # Save scaler
        import joblib
        joblib.dump(self.scaler, f'{prefix}_scaler.pkl')
        print(f"Saved scaler to {prefix}_scaler.pkl")
        
        # Save RFE selector
        if self.rfe_selector is not None:
            joblib.dump(self.rfe_selector, f'{prefix}_rfe_selector.pkl')
            print(f"Saved RFE selector to {prefix}_rfe_selector.pkl")


def main():
    print("="*70)
    print("RESOURCE-EFFICIENT PREPROCESSING FOR HYBRID CNN-LSTM")
    print("Adopted from Bamber et al. 2025")
    print("Method: Recursive Feature Elimination (RFE) with Decision Tree")
    print("="*70)
    
    # Initialize resource-efficient preprocessor
    preprocessor = ResourceEfficientCNNLSTMPreprocessor(
        n_features_to_select=None,      # Auto-select optimal features (or set specific number)
        rfe_step=1,                      # Remove 1 feature at a time
        variance_threshold=0.01,         # Remove low variance features
        scaler_type='standard',          # StandardScaler for deep learning
        balance_method=None,             # 'smote', 'adasyn', 'hybrid', or None
        dataset_version='2019',          # or '2023'
        use_rfecv=False,                 # Set True for cross-validated RFE (slower but optimal)
        cv_folds=5                       # CV folds if using RFECV
    )
    
    # Preprocess data for CNN-LSTM with resource-efficient RFE
    train_loader, val_loader, X_test, y_test, info = preprocessor.preprocess_for_cnn_lstm(
        filepath='Dataset/cicddos2019_dataset.csv',
        label_col=None,                  # Auto-detect
        test_size=0.2,                   # 20% test set
        val_size=0.1,                    # 10% validation set
        remove_low_variance=True,        # Remove constant features
        balance_train=False,             # Set True if severe imbalance
        batch_size=256,                  # Batch size for training
        visualize=True,                  # Generate plots
        rfe_sample_size=50000            # Sample size for RFE (adjust based on memory)
    )
    
    # Save preprocessing artifacts
    preprocessor.save_preprocessing_artifacts(info, prefix='rfe_cnn_lstm')
    
    print("\n" + "="*70)
    print("RESOURCE EFFICIENCY GAINS")
    print("="*70)
    print(f"• Reduced features by: {info['preprocessing_stats']['feature_reduction_percent']:.1f}%")
    print(f"• Memory savings: ~{info['preprocessing_stats']['feature_reduction_percent']:.1f}%")
    print(f"• Training speedup: ~{info['preprocessing_stats']['original_shape'][1]/info['n_features_selected']:.2f}x faster")
    print(f"• Inference speedup: ~{info['preprocessing_stats']['original_shape'][1]/info['n_features_selected']:.2f}x faster")
    print("="*70)
    
    # Now ready to train CNN-LSTM model with reduced features!
    print("\nReady for CNN-LSTM training with optimized feature set!")

if __name__ == "__main__":
    main()