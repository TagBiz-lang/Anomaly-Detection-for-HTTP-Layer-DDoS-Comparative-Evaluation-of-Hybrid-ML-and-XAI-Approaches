"""
CNN-LSTM Training Script with Testing
"""

import torch
import numpy as np
import json
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from hybrid_cnn_lstm_ddos import XAIHybridCNNLSTMDetector
from datetime import datetime

import os

BASE_FOLDER = os.path.dirname(os.path.abspath(__file__))

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")
if torch.cuda.is_available():
    print(f"GPU: {torch.cuda.get_device_name(0)}")

print("="*70)
print("TRAINING HYBRID CNN-LSTM MODEL")
print("="*70)

# Initialize model
detector = XAIHybridCNNLSTMDetector(
    sequence_length=10,
    cnn_filters=[64, 128, 256],
    kernel_size=3,
    lstm_hidden_size=128,
    lstm_layers=2,
    dropout=0.3,
    learning_rate=0.001,
    batch_size=256,
    epochs=50,
    random_state=42
)

# Load preprocessing artifacts
print("\nLoading preprocessing artifacts...")
try:
    # Check if files exist
    import os
    required_files = [
    os.path.join(BASE_FOLDER, 'cnn_lstm_preprocessing_info.json'),
    os.path.join(BASE_FOLDER, 'cnn_lstm_scaler.pkl'),
    os.path.join(BASE_FOLDER, 'cnn_lstm_selected_features.txt')
]
    
    missing_files = [f for f in required_files if not os.path.exists(f)]
    if missing_files:
        print(f"Error: Missing files: {missing_files}")
        print("Run preprocessing script first")
        exit(1)
    
    # Load JSON with error handling
    with open(os.path.join(BASE_FOLDER, 'cnn_lstm_preprocessing_info.json'), 'r') as f:
        content = f.read()
        if not content.strip():
            print("Error: cnn_lstm_preprocessing_info.json is empty")
            print("Re-run preprocessing script")
            exit(1)
        info = json.loads(content)
    
    detector.scaler = joblib.load(os.path.join(BASE_FOLDER, 'cnn_lstm_scaler.pkl'))
    
    with open(os.path.join(BASE_FOLDER, 'cnn_lstm_selected_features.txt'), 'r') as f:
        detector.feature_names = [line.strip() for line in f]
    
    print(f"Loaded {len(detector.feature_names)} features")
    
except json.JSONDecodeError as e:
    print(f"Error: Invalid JSON in preprocessing_info.json")
    print(f"Details: {e}")
    print("Re-run preprocessing script")
    exit(1)
except Exception as e:
    print(f"Error loading files: {e}")
    print("Re-run preprocessing script")
    exit(1)

# Load and preprocess dataset
print("\nLoading dataset...")
X, y = detector.load_cic_ddos_data(os.path.join(BASE_FOLDER, 'Dataset', 'cicddos2019_dataset.csv'), '2019')

train_loader, val_loader, X_test, y_test = detector.preprocess_data(
    X, y, test_size=0.2, val_size=0.1
)

# Train model
print("\nTraining model...")
start_time = datetime.now()
detector.train_model(train_loader, val_loader)
training_duration = (datetime.now() - start_time).total_seconds()
detector.plot_training_history( os.path.join(BASE_FOLDER, 'cnn_lstm_training_history.png'))

# Test model
print("\nTesting model...")
metrics = detector.evaluate_model(X_test, y_test)

# Define key names 
f1_key = 'f1_score' if 'f1_score' in metrics else 'f1'
auc_key = 'auc_roc' if 'auc_roc' in metrics else 'auc'

# Display test results
print("\nTest Results:")
print(f"Accuracy:  {metrics['accuracy']:.4f}")
print(f"Precision: {metrics['precision']:.4f}")
print(f"Recall:    {metrics['recall']:.4f}")
print(f"F1-Score:  {metrics['f1_score']:.4f}")
print(f"AUC-ROC:   {metrics['auc_roc']:.4f}")

cm = metrics['confusion_matrix']
tn, fp, fn, tp = cm.ravel()
specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
fpr = fp / (fp + tn) if (fp + tn) > 0 else 0
fnr = fn / (fn + tp) if (fn + tp) > 0 else 0

print(f"Specificity: {specificity:.4f}")
print(f"False Positive Rate: {fpr:.4f}")
print(f"False Negative Rate: {fnr:.4f}")

# Visualize test results
print("\nGenerating visualizations...")
fig = plt.figure(figsize=(18, 10))

# Confusion Matrix
ax1 = plt.subplot(2, 3, 1)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['Benign', 'Attack'],
            yticklabels=['Benign', 'Attack'])
ax1.set_xlabel('Predicted Label', fontweight='bold')
ax1.set_ylabel('True Label', fontweight='bold')
ax1.set_title('Confusion Matrix', fontweight='bold')

# Normalized Confusion Matrix
ax2 = plt.subplot(2, 3, 2)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
sns.heatmap(cm_normalized, annot=True, fmt='.3f', cmap='RdYlGn', vmin=0, vmax=1,
            xticklabels=['Benign', 'Attack'],
            yticklabels=['Benign', 'Attack'])
ax2.set_xlabel('Predicted Label', fontweight='bold')
ax2.set_ylabel('True Label', fontweight='bold')
ax2.set_title('Normalized Confusion Matrix', fontweight='bold')

# ROC Curve
ax3 = plt.subplot(2, 3, 3)
if 'fpr' in metrics and 'tpr' in metrics:
    ax3.plot(metrics['fpr'], metrics['tpr'], 'b-', linewidth=2, 
             label=f"AUC = {metrics['auc_roc']:.4f}")
    ax3.plot([0, 1], [0, 1], 'r--', linewidth=1, label='Random')
    ax3.set_xlabel('False Positive Rate', fontweight='bold')
    ax3.set_ylabel('True Positive Rate', fontweight='bold')
    ax3.set_title('ROC Curve', fontweight='bold')
    ax3.legend(loc='lower right')
    ax3.grid(True, alpha=0.3)

# Metrics Bar Chart
ax4 = plt.subplot(2, 3, 4)
metric_names = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'AUC-ROC', 'Specificity']
metric_values = [metrics['accuracy'], metrics['precision'], metrics['recall'], 
                 metrics[f1_key], metrics.get(auc_key, 0), specificity]
colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b']
bars = ax4.bar(metric_names, metric_values, color=colors, alpha=0.7, edgecolor='black')
ax4.set_ylim([0, 1.1])
ax4.set_ylabel('Score', fontweight='bold')
ax4.set_title('Performance Metrics', fontweight='bold')
for bar, value in zip(bars, metric_values):
    height = bar.get_height()
    ax4.text(bar.get_x() + bar.get_width()/2., height + 0.02,
             f'{value:.3f}', ha='center', va='bottom', fontweight='bold', fontsize=9)
ax4.tick_params(axis='x', rotation=45)

# Class Distribution
ax5 = plt.subplot(2, 3, 5)
class_counts = np.bincount(y_test.numpy() if isinstance(y_test, torch.Tensor) else y_test)
ax5.pie(class_counts, labels=['Benign', 'Attack'], autopct='%1.1f%%',
        colors=['#90EE90', '#FFB6C1'], startangle=90, explode=(0.05, 0.05))
ax5.set_title('Test Set Class Distribution', fontweight='bold')

# Summary Table
ax6 = plt.subplot(2, 3, 6)
ax6.axis('off')
summary_data = [
    ['Metric', 'Value'],
    ['Total Samples', f"{len(y_test):,}"],
    ['Accuracy', f"{metrics['accuracy']*100:.2f}%"],
    ['Precision', f"{metrics['precision']:.4f}"],
    ['Recall', f"{metrics['recall']:.4f}"],
    ['F1-Score', f"{metrics['f1_score']:.4f}"],
    ['AUC-ROC', f"{metrics['auc_roc']:.4f}"],
    ['Training Time', f"{training_duration/60:.2f} min"],
]
table = ax6.table(cellText=summary_data, cellLoc='left', loc='center',
                  colWidths=[0.5, 0.5])
table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1, 2)
for i in range(2):
    table[(0, i)].set_facecolor('#4CAF50')
    table[(0, i)].set_text_props(weight='bold', color='white')
for i in range(1, len(summary_data)):
    for j in range(2):
        if i % 2 == 0:
            table[(i, j)].set_facecolor('#f0f0f0')
ax6.set_title('Summary Statistics', fontweight='bold', pad=20)

plt.tight_layout()
plt.savefig( os.path.join(BASE_FOLDER,'cnn_lstm_test_results.png'), dpi=300, bbox_inches='tight')
print("Saved test results visualization")
plt.close()


# SECTION 6: SAVE MODEL AND RESULTS
print("\n" + "="*70)
print("SAVING MODEL AND RESULTS")
print("="*70)

# Save model
detector.save_model( os.path.join(BASE_FOLDER,'xai_cnn_lstm_ddos_model.pth'))


print("Model saved to xai_cnn_lstm_ddos_model.pth")

# Save test metrics to JSON
test_results = {
    'test_metrics': {
        'accuracy': float(metrics['accuracy']),
        'precision': float(metrics['precision']),
        'recall': float(metrics['recall']),
        'f1_score': float(metrics[f1_key]),
        'auc_roc': float(metrics['auc_roc']),
        'specificity': float(specificity),
        'fpr': float(fpr),
        'fnr': float(fnr)
    },
    'confusion_matrix': {
        'true_negatives': int(tn),
        'false_positives': int(fp),
        'false_negatives': int(fn),
        'true_positives': int(tp)
    },
    'dataset_info': {
        'total_test_samples': int(len(y_test)),
        'benign_samples': int(class_counts[0]),
        'attack_samples': int(class_counts[1])
    },
    'training_info': {
        'training_duration_minutes': float(training_duration/60),
        'training_start': start_time.strftime('%Y-%m-%d %H:%M:%S'),
        'training_end': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'epochs': detector.epochs,
        'batch_size': detector.batch_size,
        'learning_rate': detector.learning_rate
    },
    'model_architecture': {
        'sequence_length': detector.sequence_length,
        'cnn_filters': detector.cnn_filters,
        'kernel_size': detector.kernel_size,
        'lstm_hidden_size': detector.lstm_hidden_size,
        'lstm_layers': detector.lstm_layers,
        'dropout': detector.dropout
    }
}

with open(os.path.join(BASE_FOLDER,'cnn_lstm_test_results.json'), 'w') as f:
    json.dump(test_results, f, indent=2)
print("✓ Test results saved to cnn_lstm_test_results.json")

# SECTION 7: FINAL SUMMARY
print("TRAINING AND TESTING COMPLETE!")

print("\nResults Summary:")
print(f"   Test Accuracy:  {metrics['accuracy']*100:.2f}%")
print(f"   Test F1-Score:  {metrics[f1_key]:.4f}")
print(f"   Test AUC-ROC:   {metrics['auc_roc']:.4f}")
print(f"   Training Time:  {training_duration/60:.2f} minutes")

print("Saved Files:")
print("   xai_cnn_lstm_ddos_model.pth - Trained model")
print("   cnn_lstm_training_history.png - Training curves")
print("   cnn_lstm_test_results.png - Test visualizations")
print("   cnn_lstm_test_results.json - Test metrics")

