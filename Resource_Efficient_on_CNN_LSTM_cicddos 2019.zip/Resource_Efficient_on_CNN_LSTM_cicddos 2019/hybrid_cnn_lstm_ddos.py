# My Thesis Work
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (classification_report, confusion_matrix, 
                            accuracy_score, precision_recall_fscore_support,
                            roc_auc_score, roc_curve)

from captum.attr import IntegratedGradients, DeepLift, GradientShap, LayerGradCam
from datetime import datetime
import joblib
import json
import warnings
warnings.filterwarnings('ignore')

# Set device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")


class HybridCNNLSTMClassifier(nn.Module):
    
    
    def __init__(self, input_dim, sequence_length=10, cnn_filters=[64, 128, 256],
                 kernel_size=3, lstm_hidden_size=128, lstm_layers=2,
                 dropout=0.3, num_classes=2):
   
        
        super(HybridCNNLSTMClassifier, self).__init__()
        
        self.input_dim = input_dim
        self.sequence_length = sequence_length
        self.lstm_hidden_size = lstm_hidden_size
        self.lstm_layers = lstm_layers
        
        # CNN layers for spatial feature extraction
        cnn_layers = []
        in_channels = 1
        
        for out_channels in cnn_filters:
            cnn_layers.extend([
                nn.Conv1d(in_channels, out_channels, kernel_size=kernel_size, 
                         padding=kernel_size//2),
                nn.BatchNorm1d(out_channels),
                nn.ReLU(),
                nn.MaxPool1d(kernel_size=2, stride=2),
                nn.Dropout(dropout)
            ])
            in_channels = out_channels
        
        self.cnn = nn.Sequential(*cnn_layers)
        
        # Calculate CNN output size
        self.cnn_output_size = self._get_cnn_output_size(input_dim)
        
        # LSTM layers for temporal pattern recognition
        self.lstm = nn.LSTM(
            input_size=cnn_filters[-1],
            hidden_size=lstm_hidden_size,
            num_layers=lstm_layers,
            batch_first=True,
            dropout=dropout if lstm_layers > 1 else 0,
            bidirectional=True
        )
        
        # Attention mechanism for LSTM outputs
        self.attention = nn.Sequential(
            nn.Linear(lstm_hidden_size * 2, lstm_hidden_size),
            nn.Tanh(),
            nn.Linear(lstm_hidden_size, 1)
        )
        
        # Classification head
        self.classifier = nn.Sequential(
            nn.Linear(lstm_hidden_size * 2, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, num_classes)
        )
        
        # Store intermediate outputs for explainability
        self.cnn_features = None
        self.lstm_outputs = None
        self.attention_weights = None
        
    def _get_cnn_output_size(self, input_size):
        """Calculate CNN output dimensions"""
        x = torch.randn(1, 1, input_size)
        x = self.cnn(x)
        return x.shape[-1]
    
    def forward(self, x):
        """
        Forward pass
        
        Args:
            x: Input tensor of shape (batch_size, input_dim)
        
        Returns:
            Output logits
        """
        batch_size = x.size(0)
        
        # Reshape for CNN: (batch_size, 1, input_dim)
        x = x.unsqueeze(1)
        
        # CNN feature extraction
        cnn_out = self.cnn(x)  # (batch_size, cnn_filters[-1], reduced_length)
        self.cnn_features = cnn_out
        
        # Reshape for LSTM: (batch_size, seq_len, features)
        cnn_out = cnn_out.transpose(1, 2)  # (batch_size, reduced_length, cnn_filters[-1])
        
        # LSTM temporal modeling
        lstm_out, (hidden, cell) = self.lstm(cnn_out)  # (batch_size, seq_len, hidden_size*2)
        self.lstm_outputs = lstm_out
        
        # Attention mechanism
        attention_scores = self.attention(lstm_out)  # (batch_size, seq_len, 1)
        attention_weights = torch.softmax(attention_scores, dim=1)
        self.attention_weights = attention_weights
        
        # Weighted sum using attention
        context_vector = torch.sum(attention_weights * lstm_out, dim=1)  # (batch_size, hidden_size*2)
        
        # Classification
        output = self.classifier(context_vector)  # (batch_size, num_classes)
        
        return output
    
    def get_attention_weights(self):
        """Return attention weights for visualization"""
        return self.attention_weights
    
    def get_cnn_features(self):
        """Return CNN features for analysis"""
        return self.cnn_features


class XAIHybridCNNLSTMDetector:
    """
    Explainable AI-powered Hybrid CNN-LSTM DDoS Detection System
    """
    
    def __init__(self, sequence_length=10, cnn_filters=[64, 128, 256],
                 kernel_size=3, lstm_hidden_size=128, lstm_layers=2,
                 dropout=0.3, learning_rate=0.001, batch_size=256,
                 epochs=50, random_state=42):
        """
        Initialize the XAI Hybrid CNN-LSTM DDoS Detector
        
        Args:
            sequence_length: Sequence length for temporal modeling
            cnn_filters: CNN filter sizes
            kernel_size: CNN kernel size
            lstm_hidden_size: LSTM hidden size
            lstm_layers: Number of LSTM layers
            dropout: Dropout rate
            learning_rate: Learning rate
            batch_size: Batch size
            epochs: Training epochs
            random_state: Random seed
        """
        self.sequence_length = sequence_length
        self.cnn_filters = cnn_filters
        self.kernel_size = kernel_size
        self.lstm_hidden_size = lstm_hidden_size
        self.lstm_layers = lstm_layers
        self.dropout = dropout
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.epochs = epochs
        self.random_state = random_state
        
        # Set random seeds
        torch.manual_seed(random_state)
        np.random.seed(random_state)
        
        self.model = None
        self.scaler = StandardScaler()
        self.feature_names = None
        self.class_names = ['Benign', 'Attack']
        self.training_history = {'train_loss': [], 'train_acc': [],
                                'val_loss': [], 'val_acc': []}
        
        # XAI components
        self.integrated_gradients = None
        self.deep_lift = None
        self.gradient_shap = None
        self.feature_importance = None
        
    def load_cic_ddos_data(self, filepath, dataset_version='2019'):
        """
        Load and preprocess CIC-DDoS dataset
        
        Args:
            filepath: Path to CSV file
            dataset_version: '2019' or '2023'
        
        Returns:
            X: Features
            y: Labels
        """
        print(f"Loading CIC-DDoS {dataset_version} dataset from {filepath}...")
        df = pd.read_csv(filepath)
        
        # Handle common column name variations
        label_cols = ['Label', 'label', ' Label', 'Attack']
        label_col = None
        for col in label_cols:
            if col in df.columns:
                label_col = col
                break
        
        if label_col is None:
            raise ValueError("Label column not found in dataset")
        
        # Store original labels
        self.original_labels = df[label_col].unique()
        print(f"Found attack types: {self.original_labels}")
        
        # Separate features and labels
        y = df[label_col]
        X = df.drop(columns=[label_col])
        
        # Clean column names
        X.columns = X.columns.str.strip()
        
        # Handle infinite and missing values
        X.replace([np.inf, -np.inf], np.nan, inplace=True)
        X.fillna(0, inplace=True)
        
        # Remove non-numeric columns
        numeric_cols = X.select_dtypes(include=[np.number]).columns
        X = X[numeric_cols]
        
        # Store feature names
        self.feature_names = X.columns.tolist()
        
        print(f"Dataset shape: {X.shape}")
        print(f"Number of features: {len(self.feature_names)}")
        print(f"Attack distribution:\n{y.value_counts()}")
        
        return X, y
    
    def preprocess_data(self, X, y, test_size=0.2, val_size=0.1):
        """
        Preprocess and split data
        
        Args:
            X: Features
            y: Labels
            test_size: Test set proportion
            val_size: Validation set proportion
        
        Returns:
            Data loaders and test data
        """
        print("\nPreprocessing data for CNN-LSTM architecture...")
        
        # Encode labels (Binary: Benign=0, Attack=1)
        y_binary = y.apply(lambda x: 0 if 'benign' in str(x).lower() else 1)
        
        # Split data: train, validation, test
        X_temp, X_test, y_temp, y_test = train_test_split(
            X, y_binary, test_size=test_size, random_state=self.random_state,
            stratify=y_binary
        )
        
        X_train, X_val, y_train, y_val = train_test_split(
            X_temp, y_temp, test_size=val_size/(1-test_size),
            random_state=self.random_state, stratify=y_temp
        )
        
        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_val_scaled = self.scaler.transform(X_val)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Convert to PyTorch tensors
        X_train_tensor = torch.FloatTensor(X_train_scaled)
        y_train_tensor = torch.LongTensor(y_train.values)
        
        X_val_tensor = torch.FloatTensor(X_val_scaled)
        y_val_tensor = torch.LongTensor(y_val.values)
        
        X_test_tensor = torch.FloatTensor(X_test_scaled)
        y_test_tensor = torch.LongTensor(y_test.values)
        
        # Create datasets and data loaders
        train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
        val_dataset = TensorDataset(X_val_tensor, y_val_tensor)
        
        train_loader = DataLoader(
            train_dataset, batch_size=self.batch_size, shuffle=True
        )
        val_loader = DataLoader(
            val_dataset, batch_size=self.batch_size, shuffle=False
        )
        
        print(f"Training set: {X_train_scaled.shape}")
        print(f"Validation set: {X_val_scaled.shape}")
        print(f"Test set: {X_test_scaled.shape}")
        print(f"Class distribution - Train: {pd.Series(y_train).value_counts().to_dict()}")
        print(f"Class distribution - Val: {pd.Series(y_val).value_counts().to_dict()}")
        print(f"Class distribution - Test: {pd.Series(y_test).value_counts().to_dict()}")
        
        return train_loader, val_loader, X_test_tensor, y_test_tensor
    
    def train_model(self, train_loader, val_loader):
        """
        Train the Hybrid CNN-LSTM model
        
        Args:
            train_loader: Training data loader
            val_loader: Validation data loader
        """
        print(f"\nTraining Hybrid CNN-LSTM model on {device}...")
        print(f"Architecture: CNN filters={self.cnn_filters}, "
              f"LSTM hidden={self.lstm_hidden_size}, layers={self.lstm_layers}")
        
        # Get input dimension from first batch
        sample_batch = next(iter(train_loader))[0]
        input_dim = sample_batch.shape[1]
        
        # Initialize model
        self.model = HybridCNNLSTMClassifier(
            input_dim=input_dim,
            sequence_length=self.sequence_length,
            cnn_filters=self.cnn_filters,
            kernel_size=self.kernel_size,
            lstm_hidden_size=self.lstm_hidden_size,
            lstm_layers=self.lstm_layers,
            dropout=self.dropout,
            num_classes=2
        ).to(device)
        
        print(f"\nModel Summary:")
        print(f"{'='*60}")
        total_params = sum(p.numel() for p in self.model.parameters())
        trainable_params = sum(p.numel() for p in self.model.parameters() if p.requires_grad)
        print(f"Total parameters: {total_params:,}")
        print(f"Trainable parameters: {trainable_params:,}")
        print(f"{'='*60}")
        
        # Loss and optimizer
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(self.model.parameters(), lr=self.learning_rate,
                              weight_decay=1e-5)
    
        class VerboseReduceLROnPlateau(optim.lr_scheduler.ReduceLROnPlateau):
             def _reduce_lr(self, epoch):
                  super()._reduce_lr(epoch)
                  print(f'Learning rate adjusted to {self.optimizer.param_groups[0]["lr"]:.6f}')
        scheduler = VerboseReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5)
        
        best_val_loss = float('inf')
        patience_counter = 0
        patience = 10
        
        start_time = datetime.now()
        
        print(f"\nStarting training for {self.epochs} epochs...")
        print(f"{'='*70}")
        
        for epoch in range(self.epochs):
            # Training phase
            self.model.train()
            train_loss = 0.0
            train_correct = 0
            train_total = 0
            
            for batch_idx, (batch_X, batch_y) in enumerate(train_loader):
                batch_X, batch_y = batch_X.to(device), batch_y.to(device)
                
                optimizer.zero_grad()
                outputs = self.model(batch_X)
                loss = criterion(outputs, batch_y)
                loss.backward()
                
                # Gradient clipping to prevent exploding gradients
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                
                optimizer.step()
                
                train_loss += loss.item()
                _, predicted = torch.max(outputs.data, 1)
                train_total += batch_y.size(0)
                train_correct += (predicted == batch_y).sum().item()
            
            train_loss /= len(train_loader)
            train_acc = 100 * train_correct / train_total
            
            # Validation phase
            self.model.eval()
            val_loss = 0.0
            val_correct = 0
            val_total = 0
            
            with torch.no_grad():
                for batch_X, batch_y in val_loader:
                    batch_X, batch_y = batch_X.to(device), batch_y.to(device)
                    outputs = self.model(batch_X)
                    loss = criterion(outputs, batch_y)
                    
                    val_loss += loss.item()
                    _, predicted = torch.max(outputs.data, 1)
                    val_total += batch_y.size(0)
                    val_correct += (predicted == batch_y).sum().item()
            
            val_loss /= len(val_loader)
            val_acc = 100 * val_correct / val_total
            
            # Store history
            self.training_history['train_loss'].append(train_loss)
            self.training_history['train_acc'].append(train_acc)
            self.training_history['val_loss'].append(val_loss)
            self.training_history['val_acc'].append(val_acc)
            
            # Learning rate scheduling
            scheduler.step(val_loss)
            
            # Print progress
            if (epoch + 1) % 5 == 0 or epoch == 0:
                print(f"Epoch [{epoch+1:3d}/{self.epochs}] | "
                      f"Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.2f}% | "
                      f"Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.2f}%")
            
            # Early stopping
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
                # Save best model
                best_model_state = self.model.state_dict().copy()
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    print(f"\nEarly stopping triggered at epoch {epoch+1}")
                    # Restore best model
                    self.model.load_state_dict(best_model_state)
                    break
        
        training_time = (datetime.now() - start_time).total_seconds()
        
        print(f"{'='*70}")
        print(f"Training completed in {training_time:.2f} seconds")
        print(f"Best validation loss: {best_val_loss:.4f}")
    
    def evaluate_model(self, X_test, y_test):
        """
        Evaluate model performance
        
        Args:
            X_test: Test features (tensor)
            y_test: Test labels (tensor)
        
        Returns:
            Dictionary with evaluation metrics
        """
        print("\nEvaluating Hybrid CNN-LSTM model...")
        
        self.model.eval()
        
        with torch.no_grad():
            X_test = X_test.to(device)
            y_test_cpu = y_test.cpu().numpy()
            
            outputs = self.model(X_test)
            _, y_pred = torch.max(outputs.data, 1)
            y_pred_cpu = y_pred.cpu().numpy()
            
            # Get probabilities
            probs = torch.softmax(outputs, dim=1)
            y_pred_proba = probs[:, 1].cpu().numpy()
        
        # Metrics
        accuracy = accuracy_score(y_test_cpu, y_pred_cpu)
        precision, recall, f1, _ = precision_recall_fscore_support(
            y_test_cpu, y_pred_cpu, average='binary'
        )
        
        try:
            auc_roc = roc_auc_score(y_test_cpu, y_pred_proba)
        except:
            auc_roc = 0.0
        
        # Confusion matrix
        cm = confusion_matrix(y_test_cpu, y_pred_cpu)
        
        # Calculate detection metrics
        tn, fp, fn, tp = cm.ravel()
        false_positive_rate = fp / (fp + tn) if (fp + tn) > 0 else 0
        false_negative_rate = fn / (fn + tp) if (fn + tp) > 0 else 0
        
        metrics = {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': f1,
            'auc_roc': auc_roc,
            'confusion_matrix': cm,
            'false_positive_rate': false_positive_rate,
            'false_negative_rate': false_negative_rate
        }
        
        print(f"\n{'='*50}")
        print("HYBRID CNN-LSTM MODEL PERFORMANCE METRICS")
        print(f"{'='*50}")
        print(f"Accuracy:  {accuracy:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall:    {recall:.4f}")
        print(f"F1-Score:  {f1:.4f}")
        print(f"AUC-ROC:   {auc_roc:.4f}")
        print(f"\nFalse Positive Rate: {false_positive_rate:.4f}")
        print(f"False Negative Rate: {false_negative_rate:.4f}")
        print(f"\nConfusion Matrix:")
        print(f"                Predicted")
        print(f"              Benign  Attack")
        print(f"Actual Benign   {cm[0][0]:5d}  {cm[0][1]:5d}")
        print(f"       Attack   {cm[1][0]:5d}  {cm[1][1]:5d}")
        print(f"{'='*50}\n")
        
        return metrics
    
    def initialize_explainers(self):
        """
        Initialize Captum explainers for deep learning interpretability
        """
        print("Initializing XAI explainers for Hybrid CNN-LSTM model...")
        
        # Integrated Gradients
        self.integrated_gradients = IntegratedGradients(self.model)
        
        # DeepLift
        self.deep_lift = DeepLift(self.model)
        
        # Gradient SHAP
        self.gradient_shap = GradientShap(self.model)
        
        print("XAI explainers initialized successfully")
        print("Available methods: Integrated Gradients, DeepLift, Gradient SHAP")
    
    def explain_global_feature_importance(self, X_test, y_test, n_samples=1000):
        """
        Generate global feature importance using Integrated Gradients
        
        Args:
            X_test: Test features (tensor)
            y_test: Test labels (tensor)
            n_samples: Number of samples to use
        
        Returns:
            Feature importance dictionary
        """
        print("\nGenerating global feature importance...")
        
        self.model.train()
        
        # Sample data
        if len(X_test) > n_samples:
            indices = np.random.choice(len(X_test), n_samples, replace=False)
            X_sample = X_test[indices].to(device)
            y_sample = y_test[indices].to(device)
        else:
            X_sample = X_test.to(device)
            y_sample = y_test.to(device)
        
        # Calculate attributions
        attributions = self.integrated_gradients.attribute(
            X_sample, target=1, n_steps=50
        )
        
        # Convert to numpy
        attributions_np = attributions.cpu().detach().numpy()
        
        # Calculate mean absolute attribution
        feature_importance_dict = {}
        for i, feature in enumerate(self.feature_names):
            feature_importance_dict[feature] = np.abs(attributions_np[:, i]).mean()
        
        # Sort by importance
        sorted_features = sorted(
            feature_importance_dict.items(),
            key=lambda x: x[1],
            reverse=True
        )[:20]
        
        print("\nTop 20 Features by Importance (CNN-LSTM):")
        print(f"{'='*60}")
        for i, (feature, importance) in enumerate(sorted_features, 1):
            print(f"{i:2d}. {feature:40s} {importance:.6f}")
        print(f"{'='*60}")
        
        self.feature_importance = dict(sorted_features)
        
        return feature_importance_dict
    
    def explain_with_attention(self, instance):
        """
        Explain prediction using attention weights
        
        Args:
            instance: Input tensor
        
        Returns:
            Attention visualization data
        """
        self.model.eval()
        
        if instance.dim() == 1:
            instance = instance.unsqueeze(0)
        
        instance = instance.to(device)
        
        with torch.no_grad():
            output = self.model(instance)
            attention_weights = self.model.get_attention_weights()
            
            if attention_weights is not None:
                attention_weights = attention_weights.cpu().numpy().squeeze()
        
        print(f"\n{'='*70}")
        print("ATTENTION-BASED EXPLANATION")
        print(f"{'='*70}")
        print("Attention weights show which temporal positions")
        print("the model focuses on for making predictions.")
        print(f"\nAttention distribution shape: {attention_weights.shape}")
        print(f"Mean attention: {attention_weights.mean():.6f}")
        print(f"Max attention: {attention_weights.max():.6f}")
        print(f"Min attention: {attention_weights.min():.6f}")
        print(f"{'='*70}\n")
        
        return attention_weights
    
    def explain_instance(self, instance, method='integrated_gradients', top_k=10):
        """
        Explain a single prediction
        
        Args:
            instance: Input tensor
            method: XAI method to use
            top_k: Number of top features
        
        Returns:
            Explanation dictionary
        """
        self.model.train()
        
        if instance.dim() == 1:
            instance = instance.unsqueeze(0)
        
        instance = instance.to(device)
        
        # Get prediction
        with torch.no_grad():
            output = self.model(instance)
            probs = torch.softmax(output, dim=1)
            pred_class = torch.argmax(probs, dim=1).item()
            confidence = probs[0, pred_class].item()
        
        # Calculate attributions
        if method == 'integrated_gradients':
            attributions = self.integrated_gradients.attribute(
                instance, target=pred_class, n_steps=50
            )
        elif method == 'deep_lift':
            baseline = torch.zeros_like(instance).to(device)
            attributions = self.deep_lift.attribute(
                instance, baselines=baseline, target=pred_class
            )
        elif method == 'gradient_shap':
            baseline_dist = torch.randn(10, instance.shape[1]).to(device) * 0.1
            attributions = self.gradient_shap.attribute(
                instance, baselines=baseline_dist, target=pred_class, n_samples=50
            )
        else:
            raise ValueError(f"Unknown method: {method}")
        
        # Convert to numpy
        attr_np = attributions.cpu().detach().numpy()[0]
        
        # Get top features
        top_indices = np.argsort(np.abs(attr_np))[-top_k:][::-1]
        
        explanation = {
            'prediction': self.class_names[pred_class],
            'confidence': confidence,
            'method': method,
            'top_features': []
        }
        
        print(f"\n{'='*70}")
        print(f"PREDICTION EXPLANATION ({method.upper()})")
        print(f"{'='*70}")
        print(f"Prediction: {self.class_names[pred_class]}")
        print(f"Confidence: {confidence*100:.2f}%")
        print(f"\nTop {top_k} Contributing Features:")
        print(f"{'='*70}")
        
        for idx in top_indices:
            feature_name = self.feature_names[idx]
            attribution = attr_np[idx]
            direction = "→ Attack" if attribution > 0 else "→ Benign"
            
            print(f"{feature_name:40s} {attribution:+.6f} {direction}")
            
            explanation['top_features'].append({
                'feature': feature_name,
                'attribution': float(attribution),
                'direction': 'attack' if attribution > 0 else 'benign'
            })
        
        print(f"{'='*70}\n")
        
        # Also show attention weights
        attention = self.explain_with_attention(instance)
        explanation['attention_weights'] = attention.tolist() if attention is not None else None
        
        return explanation
    
    def generate_human_explanation(self, instance):
        """
        Generate human-readable explanation
        
        Args:
            instance: Input tensor
        
        Returns:
            Human-readable explanation string
        """
        self.model.train() 
        
        if instance.dim() == 1:
            instance = instance.unsqueeze(0)
        
        instance = instance.to(device)
        
        # Get prediction
        with torch.no_grad():
            output = self.model(instance)
            probs = torch.softmax(output, dim=1)
            pred_class = torch.argmax(probs, dim=1).item()
            confidence = probs[0, pred_class].item()
            cnn_features = self.model.get_cnn_features()
            attention_weights = self.model.get_attention_weights()
        
        # Get attributions
        attributions = self.integrated_gradients.attribute(
            instance, target=pred_class, n_steps=50
        )
        attr_np = attributions.cpu().detach().numpy()[0]
        
        # Top 5 features
        top_indices = np.argsort(np.abs(attr_np))[-5:][::-1]
        
        # Build explanation
        explanation = f"\n{'='*70}\n"
        explanation += "HUMAN-READABLE EXPLANATION (HYBRID CNN-LSTM)\n"
        explanation += f"{'='*70}\n\n"
        
        if pred_class == 1:  # Attack
            explanation += f"⚠️  ALERT: Potential DDoS Attack Detected\n"
            explanation += f"Confidence: {confidence*100:.2f}%\n\n"
            explanation += "How the Hybrid CNN-LSTM model detected this attack:\n\n"
            explanation += "📊 CNN Analysis (Spatial Features):\n"
            explanation += "   The CNN layers identified suspicious patterns in the\n"
            explanation += "   feature space that resemble known attack signatures.\n\n"
            explanation += "⏱️  LSTM Analysis (Temporal Patterns):\n"
            explanation += "   The LSTM layers detected abnormal temporal sequences\n"
            explanation += "   characteristic of coordinated DDoS attacks.\n\n"
        else:  # Benign
            explanation += f"✓ Normal Traffic Detected\n"
            explanation += f"Confidence: {confidence*100:.2f}%\n\n"
            explanation += "Why this traffic is classified as benign:\n\n"
            explanation += "📊 CNN Analysis (Spatial Features):\n"
            explanation += "   The CNN layers identified normal patterns consistent\n"
            explanation += "   with legitimate user behavior.\n\n"
            explanation += "⏱️  LSTM Analysis (Temporal Patterns):\n"
            explanation += "   The LSTM layers detected regular temporal patterns\n"
            explanation += "   typical of normal network traffic.\n\n"
        
        explanation += "🔍 Key Contributing Features:\n\n"
        
        for i, idx in enumerate(top_indices, 1):
            feature_name = self.feature_names[idx]
            attribution = attr_np[idx]
            
            if abs(attribution) > 0.001:
                explanation += f"{i}. {feature_name}\n"
                if attribution > 0:
                    explanation += f"   → Strongly indicates attack behavior\n"
                else:
                    explanation += f"   → Indicates normal behavior\n"
                explanation += f"   → Attribution: {attribution:+.6f}\n\n"
        
        if attention_weights is not None:
            attention_np = attention_weights.cpu().numpy().squeeze()
            max_attention_idx = np.argmax(attention_np)
            max_attention_val = attention_np[max_attention_idx]
            
            explanation += f"🎯 Attention Focus:\n"
            explanation += f"   The model paid most attention to temporal position {max_attention_idx}\n"
            explanation += f"   with weight {max_attention_val:.4f}, indicating this part of the\n"
            explanation += f"   sequence was most critical for the classification.\n\n"
        
        explanation += "💡 Model Architecture:\n"
        explanation += "   - CNN extracts spatial features from traffic data\n"
        explanation += "   - LSTM captures temporal dependencies and sequences\n"
        explanation += "   - Attention mechanism highlights important time steps\n"
        explanation += f"{'='*70}\n"
        
        print(explanation)
        return explanation
    
    def detect_realtime_attack(self, traffic_features):
        """
        Detect DDoS attack in real-time traffic
        
        Args:
            traffic_features: Dictionary or DataFrame with traffic features
        
        Returns:
            Dictionary with prediction and explanation
        """
        # Convert to DataFrame if dictionary
        if isinstance(traffic_features, dict):
            traffic_df = pd.DataFrame([traffic_features])
        else:
            traffic_df = traffic_features
        
        # Ensure all features are present
        missing_features = set(self.feature_names) - set(traffic_df.columns)
        for feature in missing_features:
            traffic_df[feature] = 0
        
        # Reorder columns
        traffic_df = traffic_df[self.feature_names]
        
        # Scale and convert to tensor
        traffic_scaled = self.scaler.transform(traffic_df)
        traffic_tensor = torch.FloatTensor(traffic_scaled).to(device)
        
        self.model.train() 
        
        with torch.no_grad():
            output = self.model(traffic_tensor)
            probs = torch.softmax(output, dim=1)
            pred_class = torch.argmax(probs, dim=1).item()
            confidence = probs[0, pred_class].item()
            
            # Get attention weights
            attention_weights = self.model.get_attention_weights()
            if attention_weights is not None:
                attention_weights = attention_weights.cpu().numpy().squeeze().tolist()
        
        # Get attributions for explanation
        attributions = self.integrated_gradients.attribute(
            traffic_tensor, target=pred_class, n_steps=50
        )
        attr_np = attributions.cpu().detach().numpy()[0]
        
        # Top 5 features
        top_indices = np.argsort(np.abs(attr_np))[-5:][::-1]
        top_features = []
        
        for idx in top_indices:
            top_features.append({
                'feature': self.feature_names[idx],
                'attribution': float(attr_np[idx]),
                'direction': 'attack' if attr_np[idx] > 0 else 'benign'
            })
        
        result = {
            'prediction': self.class_names[pred_class],
            'confidence': float(confidence),
            'attack_probability': float(probs[0, 1].cpu().numpy()),
            'benign_probability': float(probs[0, 0].cpu().numpy()),
            'top_contributing_features': top_features,
            'attention_weights': attention_weights,
            'timestamp': datetime.now().isoformat(),
            'model_type': 'hybrid_cnn_lstm'
        }
        
        return result
    
    def visualize_cnn_features(self, instance, save_path='cnn_features.png'):
        """
        Visualize CNN extracted features
        
        Args:
            instance: Input tensor
            save_path: Path to save visualization
        """
        self.model.eval()
        
        if instance.dim() == 1:
            instance = instance.unsqueeze(0)
        
        instance = instance.to(device)
        
        with torch.no_grad():
            _ = self.model(instance)
            cnn_features = self.model.get_cnn_features()
            
            if cnn_features is not None:
                cnn_features_np = cnn_features.cpu().numpy()[0]
                
                plt.figure(figsize=(15, 5))
                plt.imshow(cnn_features_np, aspect='auto', cmap='viridis')
                plt.colorbar(label='Activation')
                plt.xlabel('Sequence Position')
                plt.ylabel('CNN Feature Maps')
                plt.title('CNN Extracted Features Visualization')
                plt.tight_layout()
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                print(f"\nCNN features visualization saved to {save_path}")
                plt.close()
    
    def visualize_attention(self, instance, save_path='attention_weights.png'):
        """
        Visualize attention weights
        
        Args:
            instance: Input tensor
            save_path: Path to save visualization
        """
        self.model.eval()
        
        if instance.dim() == 1:
            instance = instance.unsqueeze(0)
        
        instance = instance.to(device)
        
        with torch.no_grad():
            _ = self.model(instance)
            attention_weights = self.model.get_attention_weights()
            
            if attention_weights is not None:
                attention_np = attention_weights.cpu().numpy().squeeze()
                
                plt.figure(figsize=(12, 4))
                positions = np.arange(len(attention_np))
                plt.bar(positions, attention_np, color='steelblue', alpha=0.7)
                plt.xlabel('Temporal Position')
                plt.ylabel('Attention Weight')
                plt.title('LSTM Attention Weights Distribution')
                plt.grid(axis='y', alpha=0.3)
                plt.tight_layout()
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                print(f"\nAttention weights visualization saved to {save_path}")
                plt.close()
    
    def plot_training_history(self, save_path='cnn_lstm_training_history.png'):
        """
        Plot training history
        
        Args:
            save_path: Path to save plot
        """
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))
        
        # Loss plot
        ax1.plot(self.training_history['train_loss'], label='Train Loss', linewidth=2)
        ax1.plot(self.training_history['val_loss'], label='Val Loss', linewidth=2)
        ax1.set_xlabel('Epoch', fontsize=12)
        ax1.set_ylabel('Loss', fontsize=12)
        ax1.set_title('Training and Validation Loss', fontsize=14, fontweight='bold')
        ax1.legend(fontsize=10)
        ax1.grid(True, alpha=0.3)
        
        # Accuracy plot
        ax2.plot(self.training_history['train_acc'], label='Train Acc', linewidth=2)
        ax2.plot(self.training_history['val_acc'], label='Val Acc', linewidth=2)
        ax2.set_xlabel('Epoch', fontsize=12)
        ax2.set_ylabel('Accuracy (%)', fontsize=12)
        ax2.set_title('Training and Validation Accuracy', fontsize=14, fontweight='bold')
        ax2.legend(fontsize=10)
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"\nTraining history plot saved to {save_path}")
        plt.close()
    
    def save_model(self, filepath='xai_cnn_lstm_ddos_model.pth'):
        """
        Save trained model and components
        
        Args:
            filepath: Path to save model
        """
        model_package = {
            'model_state_dict': self.model.state_dict(),
            'model_config': {
                'input_dim': self.model.input_dim,
                'sequence_length': self.sequence_length,
                'cnn_filters': self.cnn_filters,
                'kernel_size': self.kernel_size,
                'lstm_hidden_size': self.lstm_hidden_size,
                'lstm_layers': self.lstm_layers,
                'dropout': self.dropout
            },
            'scaler': self.scaler,
            'feature_names': self.feature_names,
            'class_names': self.class_names,
            'feature_importance': self.feature_importance,
            'training_history': self.training_history
        }
        
        torch.save(model_package, filepath)
        print(f"\nHybrid CNN-LSTM model saved to {filepath}")
    
    def load_model(self, filepath='xai_cnn_lstm_ddos_model.pth'):
        """
        Load trained model and components
        
        Args:
            filepath: Path to model file
        """
        model_package = torch.load(filepath, map_location=device, weights_only=False)
        
        config = model_package['model_config']
        self.sequence_length = config['sequence_length']
        self.cnn_filters = config['cnn_filters']
        self.kernel_size = config['kernel_size']
        self.lstm_hidden_size = config['lstm_hidden_size']
        self.lstm_layers = config['lstm_layers']
        self.dropout = config['dropout']
        
        # Reinitialize model
        self.model = HybridCNNLSTMClassifier(
            input_dim=config['input_dim'],
            sequence_length=self.sequence_length,
            cnn_filters=self.cnn_filters,
            kernel_size=self.kernel_size,
            lstm_hidden_size=self.lstm_hidden_size,
            lstm_layers=self.lstm_layers,
            dropout=self.dropout,
            num_classes=2
        ).to(device)
        
        self.model.load_state_dict(model_package['model_state_dict'])
        self.scaler = model_package['scaler']
        self.feature_names = model_package['feature_names']
        self.class_names = model_package['class_names']
        self.feature_importance = model_package.get('feature_importance', None)
        self.training_history = model_package.get('training_history', {})
        
        self.model.eval()
        
        print(f"\nHybrid CNN-LSTM model loaded from {filepath}")
        print(f"Model configuration: CNN filters={self.cnn_filters}, "
              f"LSTM hidden={self.lstm_hidden_size}, layers={self.lstm_layers}")
        print(f"Number of features: {len(self.feature_names)}")


def main():
    """
    Main execution pipeline for Hybrid CNN-LSTM DDoS detection
    """
    print("="*70)
    print("XAI-POWERED HYBRID CNN-LSTM HTTP DDoS DETECTION SYSTEM")
    print("="*70)
    print(f"Device: {device}")
    print("="*70)
    
    # Initialize detector
    detector = XAIHybridCNNLSTMDetector(
        sequence_length=10,
        cnn_filters=[64, 128, 256],
        kernel_size=3,
        lstm_hidden_size=128,
        lstm_layers=2,
        dropout=0.3,
        learning_rate=0.001,
        batch_size=256,
        epochs=50,
        random_state=42
    )
    
    print("\n[INFO] Hybrid CNN-LSTM Architecture:")
    print("  - CNN: Extracts spatial features from traffic data")
    print("  - LSTM: Captures temporal dependencies and sequences")
    print("  - Attention: Highlights important temporal positions")
    print("  - Bidirectional LSTM: Processes sequences forward and backward")
    
    # Load data (update with your dataset path)
    print("\n[INFO] Please update the dataset path in the code")
    print("[INFO] Uncomment the following workflow and provide your dataset path:")
    print("       X, y = detector.load_cic_ddos_data('path/to/dataset.csv', '2019')")
    
    # Example workflow (uncomment when you have real data):
    """
    # 1. Load and preprocess data
    X, y = detector.load_cic_ddos_data('CIC-DDoS2019.csv', '2019')
    train_loader, val_loader, X_test, y_test = detector.preprocess_data(X, y)
    
    # 2. Train model
    detector.train_model(train_loader, val_loader)
    
    # 3. Plot training history
    detector.plot_training_history('cnn_lstm_training_history.png')
    
    # 4. Evaluate model
    metrics = detector.evaluate_model(X_test, y_test)
    
    # 5. Initialize explainers
    detector.initialize_explainers()
    
    # 6. Generate global feature importance
    feature_importance = detector.explain_global_feature_importance(X_test, y_test)
    
    # 7. Explain specific instances with multiple methods
    # Get attack samples
    attack_indices = (y_test == 1).nonzero(as_tuple=True)[0]
    if len(attack_indices) > 0:
        sample_attack = X_test[attack_indices[0]]
        
        # Integrated Gradients explanation
        exp_ig = detector.explain_instance(sample_attack, method='integrated_gradients')
        
        # DeepLift explanation
        exp_dl = detector.explain_instance(sample_attack, method='deep_lift')
        
        # Gradient SHAP explanation
        exp_gs = detector.explain_instance(sample_attack, method='gradient_shap')
        
        # Human-readable explanation
        human_exp = detector.generate_human_explanation(sample_attack)
        
        # Visualize CNN features
        detector.visualize_cnn_features(sample_attack, 'attack_cnn_features.png')
        
        # Visualize attention weights
        detector.visualize_attention(sample_attack, 'attack_attention_weights.png')
    
    # 8. Explain benign instance
    benign_indices = (y_test == 0).nonzero(as_tuple=True)[0]
    if len(benign_indices) > 0:
        sample_benign = X_test[benign_indices[0]]
        exp_benign = detector.explain_instance(sample_benign, method='integrated_gradients')
        human_exp_benign = detector.generate_human_explanation(sample_benign)
        
        # Visualize benign traffic patterns
        detector.visualize_cnn_features(sample_benign, 'benign_cnn_features.png')
        detector.visualize_attention(sample_benign, 'benign_attention_weights.png')
    
    # 9. Save model
    detector.save_model('xai_cnn_lstm_ddos_model.pth')
    
    # 10. Real-time detection example
    sample_traffic = {
        'flow_duration': 1234567,
        'total_fwd_packets': 150,
        'total_bwd_packets': 120,
        'fwd_packet_length_mean': 512.5,
        'bwd_packet_length_mean': 256.3,
        'flow_iat_mean': 1000.5,
        'flow_iat_std': 500.2,
        # ... add all required features matching your dataset
    }
    result = detector.detect_realtime_attack(sample_traffic)
    print("\nReal-time Detection Result:")
    print(json.dumps(result, indent=2))
    
    # 11. Load model for inference (optional)
    # detector_new = XAIHybridCNNLSTMDetector()
    # detector_new.load_model('xai_cnn_lstm_ddos_model.pth')
    # detector_new.initialize_explainers()
    
    # 12. Batch prediction for multiple samples
    # batch_results = []
    # for i in range(min(10, len(X_test))):
    #     sample = X_test[i]
    #     exp = detector.explain_instance(sample, method='integrated_gradients')
    #     batch_results.append(exp)
    """
    
    print("\n[SUCCESS] XAI Hybrid CNN-LSTM DDoS Detection System initialized")
    print("[INFO] Update the code with your dataset path and uncomment the workflow")
    print("\nKey Features:")
    print("✓ CNN for spatial feature extraction")
    print("✓ Bidirectional LSTM for temporal pattern recognition")
    print("✓ Attention mechanism for interpretability")
    print("✓ Multiple XAI methods: Integrated Gradients, DeepLift, Gradient SHAP")
    print("✓ Attention weight visualization")
    print("✓ CNN feature map visualization")
    print("✓ Human-readable explanations")
    print("✓ Real-time detection with explainability")
    print("✓ GPU acceleration support")
    print("✓ Early stopping and learning rate scheduling")
    print("\nAdvantages of Hybrid CNN-LSTM:")
    print("→ Combines spatial (CNN) and temporal (LSTM) analysis")
    print("→ Attention mechanism highlights critical time steps")
    print("→ Better captures complex attack patterns")
    print("→ Bidirectional processing for context from both directions")
    print("→ More interpretable than pure deep learning models")


if __name__ == "__main__":
    main()
