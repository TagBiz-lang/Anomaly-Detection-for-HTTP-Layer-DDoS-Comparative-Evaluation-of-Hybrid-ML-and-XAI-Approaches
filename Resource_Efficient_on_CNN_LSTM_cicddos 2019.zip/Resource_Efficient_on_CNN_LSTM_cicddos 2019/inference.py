"""
Real-time DDoS Detection Inference Script
"""

import torch
import numpy as np
import pandas as pd
import joblib
import json
from hybrid_cnn_lstm_ddos import XAIHybridCNNLSTMDetector
import warnings
warnings.filterwarnings('ignore')

class DDoSDetector:
    def __init__(self, model_path='xai_cnn_lstm_ddos_model.pth',
                 scaler_path='cnn_lstm_scaler.pkl',
                 features_path='cnn_lstm_selected_features.txt',
                 info_path='cnn_lstm_preprocessing_info.json'):
        
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
        # Load preprocessing artifacts
        print("Loading model and preprocessing artifacts...")
        
        with open(features_path, 'r') as f:
            self.feature_names = [line.strip() for line in f]
        
        self.scaler = joblib.load(scaler_path)
        
        with open(info_path, 'r') as f:
            self.info = json.load(f)
        
        # Initialize detector
        self.detector = XAIHybridCNNLSTMDetector(
            sequence_length=10,
            cnn_filters=[64, 128, 256],
            kernel_size=3,
            lstm_hidden_size=128,
            lstm_layers=2,
            dropout=0.3,
            learning_rate=0.001,
            batch_size=256,
            epochs=50,
            random_state=42
        )
        
        # Load trained model
        self.detector.load_model(model_path)
        self.detector.model.eval()
        
        print(f"Model loaded successfully")
        print(f"Expected features: {len(self.feature_names)}")
    
    def preprocess_sample(self, sample_df):
        """
        Preprocess a single sample or batch of samples
        
        Args:
            sample_df: DataFrame with network traffic features
        
        Returns:
            Preprocessed tensor
        """
        # Select only required features
        try:
            X = sample_df[self.feature_names]
        except KeyError as e:
            missing = set(self.feature_names) - set(sample_df.columns)
            print(f"Error: Missing features: {missing}")
            return None
        
        # Handle missing values
        X = X.fillna(0)
        
        # Handle infinite values
        X = X.replace([np.inf, -np.inf], 0)
        
        # Scale features
        X_scaled = self.scaler.transform(X)
        
        # Convert to tensor
        X_tensor = torch.FloatTensor(X_scaled).to(self.device)
        
        return X_tensor
    
    def predict_single(self, sample_df):
        """
        Predict on a single network traffic sample
        
        Args:
            sample_df: DataFrame with one row of network features
        
        Returns:
            prediction (0=Benign, 1=Attack), probability
        """
        X_tensor = self.preprocess_sample(sample_df)
        
        if X_tensor is None:
            return None, None
        
        with torch.no_grad():
            output = self.detector.model(X_tensor)
            probabilities = torch.softmax(output, dim=1)
            prediction = torch.argmax(probabilities, dim=1)
        
        pred_class = prediction.cpu().numpy()[0]
        prob = probabilities.cpu().numpy()[0]
        
        return pred_class, prob
    
    def predict_batch(self, batch_df):
        """
        Predict on a batch of network traffic samples
        
        Args:
            batch_df: DataFrame with multiple rows
        
        Returns:
            predictions array, probabilities array
        """
        X_tensor = self.preprocess_sample(batch_df)
        
        if X_tensor is None:
            return None, None
        
        with torch.no_grad():
            output = self.detector.model(X_tensor)
            probabilities = torch.softmax(output, dim=1)
            predictions = torch.argmax(probabilities, dim=1)
        
        pred_classes = predictions.cpu().numpy()
        probs = probabilities.cpu().numpy()
        
        return pred_classes, probs
    
    def detect_from_csv(self, csv_path, save_results=True):
        """
        Detect DDoS attacks from CSV file
        
        Args:
            csv_path: Path to CSV file with network traffic
            save_results: Save results to JSON
        
        Returns:
            Results dictionary
        """
        print(f"\nLoading data from {csv_path}...")
        df = pd.read_csv(csv_path, nrows=1000)  # Limit for testing
        
        print(f"Loaded {len(df)} samples")
        print("Running inference...")
        
        predictions, probabilities = self.predict_batch(df)
        
        if predictions is None:
            return None
        
        # Calculate statistics
        n_benign = np.sum(predictions == 0)
        n_attacks = np.sum(predictions == 1)
        
        results = {
            'total_samples': len(df),
            'benign_count': int(n_benign),
            'attack_count': int(n_attacks),
            'benign_percentage': float(n_benign / len(df) * 100),
            'attack_percentage': float(n_attacks / len(df) * 100),
            'predictions': predictions.tolist(),
            'attack_probabilities': probabilities[:, 1].tolist()
        }
        
        print("\nDetection Results:")
        print(f"Total Samples: {results['total_samples']}")
        print(f"Benign: {results['benign_count']} ({results['benign_percentage']:.2f}%)")
        print(f"Attacks: {results['attack_count']} ({results['attack_percentage']:.2f}%)")
        
        if save_results:
            with open('realtime_detection_result.json', 'w') as f:
                json.dump(results, f, indent=2)
            print("\nResults saved to realtime_detection_result.json")
        
        return results


def demo_single_prediction():
    """
    Demo: Single sample prediction
    """
    print("="*70)
    print("DEMO: Single Sample Prediction")
    print("="*70)
    
    detector = DDoSDetector()
    
    # Create a dummy sample (replace with real network traffic features)
    sample_data = {feat: [0.5] for feat in detector.feature_names}
    sample_df = pd.DataFrame(sample_data)
    
    prediction, probability = detector.predict_single(sample_df)
    
    label = "ATTACK" if prediction == 1 else "BENIGN"
    confidence = probability[prediction] * 100
    
    print(f"\nPrediction: {label}")
    print(f"Confidence: {confidence:.2f}%")
    print(f"Benign Probability: {probability[0]:.4f}")
    print(f"Attack Probability: {probability[1]:.4f}")


def demo_batch_prediction():
    """
    Demo: Batch prediction from CSV
    """
    print("\n" + "="*70)
    print("DEMO: Batch Prediction from CSV")
    print("="*70)
    
    detector = DDoSDetector()
    
    # Replace with your actual test CSV file
    csv_path = 'Dataset/cicddos2019_dataset.csv'
    
    try:
        results = detector.detect_from_csv(csv_path, save_results=True)
    except FileNotFoundError:
        print(f"Error: {csv_path} not found")
        print("Please provide a valid CSV file path")


def real_time_monitoring():
    """
    Demo: Real-time monitoring simulation
    """
    print("\n" + "="*70)
    print("DEMO: Real-time Monitoring")
    print("="*70)
    
    detector = DDoSDetector()
    
    print("\nSimulating real-time traffic monitoring...")
    print("Processing samples...")
    
    # Simulate 10 incoming network traffic samples
    for i in range(10):
        # Create random sample (replace with actual network data)
        sample_data = {feat: [np.random.random()] for feat in detector.feature_names}
        sample_df = pd.DataFrame(sample_data)
        
        prediction, probability = detector.predict_single(sample_df)
        
        label = "ATTACK" if prediction == 1 else "BENIGN"
        confidence = probability[prediction] * 100
        
        print(f"Sample {i+1}: {label} (Confidence: {confidence:.2f}%)")
        
        if prediction == 1:
            print(f"  WARNING: Potential DDoS attack detected!")


if __name__ == "__main__":
    print("="*70)
    print("REAL-TIME DDOS DETECTION INFERENCE")
    print("="*70)
    
    # Choose demo mode
    mode = input("\nSelect mode:\n1. Single prediction\n2. Batch prediction\n3. Real-time monitoring\nChoice (1/2/3): ")
    
    if mode == '1':
        demo_single_prediction()
    elif mode == '2':
        demo_batch_prediction()
    elif mode == '3':
        real_time_monitoring()
    else:
        print("Invalid choice. Running batch prediction...")
        demo_batch_prediction()