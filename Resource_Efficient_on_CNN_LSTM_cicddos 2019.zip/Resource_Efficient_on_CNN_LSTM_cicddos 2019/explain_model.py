import torch
import numpy as np
import json
import joblib
from hybrid_cnn_lstm_ddos import XAIHybridCNNLSTMDetector

# Set device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

print("="*70)
print("XAI EXPLANATION SCRIPT FOR HYBRID CNN-LSTM MODEL")
print("="*70)

# Initialize detector
detector = XAIHybridCNNLSTMDetector()

# Load the trained model
print("\nLoading trained model...")
detector.load_model('xai_cnn_lstm_ddos_model.pth')

# Initialize explainers
print("\nInitializing XAI explainers...")
detector.initialize_explainers()

# Load and preprocess the dataset to get test data
print("\nLoading dataset for explanations...")
X, y = detector.load_cic_ddos_data('Dataset/cicddos2019_dataset.csv', '2019')

# Preprocess data to get test set
train_loader, val_loader, X_test, y_test = detector.preprocess_data(
    X, y, test_size=0.2, val_size=0.1
)

print(f"\nTest set size: {len(X_test)} samples")
print(f"Test set shape: {X_test.shape}")

# ============================================================
# 1. GLOBAL FEATURE IMPORTANCE
# ============================================================
print("\n" + "="*70)
print("1. GENERATING GLOBAL FEATURE IMPORTANCE")
print("="*70)

feature_importance = detector.explain_global_feature_importance(
    X_test, y_test, n_samples=1000
)

# ============================================================
# 2. EXPLAIN ATTACK INSTANCES
# ============================================================
print("\n" + "="*70)
print("2. EXPLAINING ATTACK INSTANCES")
print("="*70)

attack_indices = (y_test == 1).nonzero(as_tuple=True)[0]
if len(attack_indices) > 0:
    # Select first attack sample
    sample_attack = X_test[attack_indices[0]]
    
    print("\n--- Integrated Gradients Explanation ---")
    exp_ig = detector.explain_instance(
        sample_attack, 
        method='integrated_gradients',
        top_k=10
    )
    
    print("\n--- DeepLift Explanation ---")
    exp_dl = detector.explain_instance(
        sample_attack,
        method='deep_lift',
        top_k=10
    )
    
    print("\n--- Gradient SHAP Explanation ---")
    exp_gs = detector.explain_instance(
        sample_attack,
        method='gradient_shap',
        top_k=10
    )
    
    print("\n--- Human-Readable Explanation ---")
    human_exp_attack = detector.generate_human_explanation(sample_attack)
    
    # Visualize CNN features and attention for attack
    detector.visualize_cnn_features(sample_attack, 'attack_cnn_features.png')
    detector.visualize_attention(sample_attack, 'attack_attention_weights.png')
    
    # Save explanation to JSON
    with open('attack_explanation.json', 'w') as f:
        json.dump({
            'integrated_gradients': exp_ig,
            'deep_lift': exp_dl,
            'gradient_shap': exp_gs
        }, f, indent=2)
    print("\n✓ Attack explanations saved to attack_explanation.json")

# ============================================================
# 3. EXPLAIN BENIGN INSTANCES
# ============================================================
print("\n" + "="*70)
print("3. EXPLAINING BENIGN INSTANCES")
print("="*70)

benign_indices = (y_test == 0).nonzero(as_tuple=True)[0]
if len(benign_indices) > 0:
    # Select first benign sample
    sample_benign = X_test[benign_indices[0]]
    
    print("\n--- Integrated Gradients Explanation ---")
    exp_benign = detector.explain_instance(
        sample_benign,
        method='integrated_gradients',
        top_k=10
    )
    
    print("\n--- Human-Readable Explanation ---")
    human_exp_benign = detector.generate_human_explanation(sample_benign)
    
    # Visualize CNN features and attention for benign
    detector.visualize_cnn_features(sample_benign, 'benign_cnn_features.png')
    detector.visualize_attention(sample_benign, 'benign_attention_weights.png')
    
    # Save explanation to JSON
    with open('benign_explanation.json', 'w') as f:
        json.dump(exp_benign, f, indent=2)
    print("\n✓ Benign explanations saved to benign_explanation.json")

# ============================================================
# 4. EXPLAIN MULTIPLE SAMPLES (BATCH)
# ============================================================
print("\n" + "="*70)
print("4. BATCH EXPLANATIONS (10 SAMPLES)")
print("="*70)

batch_explanations = []
num_samples = min(10, len(X_test))

for i in range(num_samples):
    sample = X_test[i]
    true_label = 'Attack' if y_test[i].item() == 1 else 'Benign'
    
    exp = detector.explain_instance(sample, method='integrated_gradients', top_k=5)
    exp['true_label'] = true_label
    exp['sample_index'] = i
    
    batch_explanations.append(exp)
    
    print(f"\nSample {i+1}/{num_samples} - True: {true_label}, "
          f"Predicted: {exp['prediction']}, "
          f"Confidence: {exp['confidence']*100:.2f}%")

# Save batch explanations
with open('batch_explanations.json', 'w') as f:
    json.dump(batch_explanations, f, indent=2)
print("\n✓ Batch explanations saved to batch_explanations.json")

# ============================================================
# 5. REAL-TIME DETECTION EXAMPLE
# ============================================================
print("\n" + "="*70)
print("5. REAL-TIME DETECTION EXAMPLE")
print("="*70)

# Use a random test sample for real-time simulation
random_idx = np.random.randint(0, len(X_test))
sample_features = X_test[random_idx]

# Convert tensor to DataFrame format for real-time detection
sample_dict = {
    feature: float(sample_features[i].item())
    for i, feature in enumerate(detector.feature_names)
}

result = detector.detect_realtime_attack(sample_dict)

print("\nReal-time Detection Result:")
print(json.dumps(result, indent=2))

# Save real-time result
with open('realtime_detection_result.json', 'w') as f:
    json.dump(result, f, indent=2)
print("\n✓ Real-time detection result saved to realtime_detection_result.json")

# ============================================================
# SUMMARY
# ============================================================
print("\n" + "="*70)
print("EXPLANATION PROCESS COMPLETE!")
print("="*70)
print("\nGenerated Files:")
print("✓ attack_explanation.json - Detailed attack explanations")
print("✓ benign_explanation.json - Detailed benign explanations")
print("✓ batch_explanations.json - 10 sample explanations")
print("✓ realtime_detection_result.json - Real-time detection example")
print("✓ attack_cnn_features.png - CNN feature visualization (attack)")
print("✓ attack_attention_weights.png - Attention visualization (attack)")
print("✓ benign_cnn_features.png - CNN feature visualization (benign)")
print("✓ benign_attention_weights.png - Attention visualization (benign)")
print("\nYou can now:")
print("→ Review the JSON files for detailed explanations")
print("→ Analyze the visualizations")
print("→ Run this script again with different samples")
print("→ Modify the script to explain specific instances")
print("="*70)