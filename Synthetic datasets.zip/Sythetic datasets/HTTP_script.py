import random
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

class HTTPProtocolAttackGenerator:
    def __init__(self):
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X)",
            "Mozilla/5.0 (Android 11; Mobile; rv:91.0) Gecko/91.0"
        ]
        
        self.normal_paths = [
            "/", "/index.html", "/about", "/contact", "/products", "/services",
            "/api/users", "/api/products", "/login", "/dashboard", "/profile",
            "/images/logo.png", "/css/style.css", "/js/main.js"
        ]
        
        # HTTP attack specific paths
        self.attack_paths = [
            "/", "/login", "/api/auth", "/search", "/upload", "/download",
            "/api/users", "/admin", "/dashboard", "/heavy-endpoint"
        ]
    
    def generate_normal_traffic(self, num_requests=3000):
        """Generate normal HTTP traffic"""
        data = []
        start_time = datetime.now()
        
        # Session management for realistic behavior
        sessions = {}
        
        for i in range(num_requests):
            # Realistic time intervals
            time_offset = np.random.exponential(60)  # Average 1 minute between requests
            timestamp = start_time + timedelta(seconds=time_offset)
            
            # Session-based behavior
            if random.random() < 0.1 or not sessions:
                session_id = f"normal_session_{len(sessions)}"
                client_ip = f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
                user_agent = random.choice(self.user_agents)
                sessions[session_id] = {"ip": client_ip, "user_agent": user_agent, "requests": 0}
            
            session_id = random.choice(list(sessions.keys()))
            session = sessions[session_id]
            session["requests"] += 1
            
            # Normal HTTP characteristics
            method = random.choices(["GET", "POST", "PUT", "DELETE"], weights=[70, 20, 5, 5])[0]
            path = random.choice(self.normal_paths)
            status_code = random.choices([200, 404, 301, 500], weights=[85, 10, 3, 2])[0]
            
            # Normal response sizes
            if path.endswith(('.png', '.jpg', '.jpeg')):
                response_size = random.randint(5000, 500000)
            elif path.endswith(('.css', '.js')):
                response_size = random.randint(1000, 50000)
            else:
                response_size = random.randint(500, 10000)
            
            request_time = random.uniform(0.1, 2.0)
            content_length = random.randint(0, 1000) if method == "POST" else 0
            
            data.append({
                "timestamp": timestamp,
                "source_ip": session["ip"],
                "method": method,
                "path": path,
                "status_code": status_code,
                "response_size": response_size,
                "user_agent": session["user_agent"],
                "request_time": request_time,
                "content_length": content_length,
                "connection_type": "keep-alive",
                "http_version": random.choice(["HTTP/1.1", "HTTP/2.0"]),
                "attack_type": "normal",
                "attack_subtype": "legitimate_traffic",
                "label": "benign"
            })
            
            # Clean up sessions
            if session["requests"] > 20:
                del sessions[session_id]
        
        return data
    
    def generate_http_flood_attack(self, num_requests=800):
        """Generate HTTP GET/POST flood attacks"""
        data = []
        start_time = datetime.now()
        
        # Botnet-like IP distribution
        attack_ips = []
        for _ in range(100):
            if random.random() < 0.3:  # 30% from similar subnets
                subnet = f"192.168.{random.randint(1, 20)}"
                attack_ips.append(f"{subnet}.{random.randint(1, 254)}")
            else:
                attack_ips.append(f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}")
        
        for i in range(num_requests):
            # Very high frequency
            time_offset = np.random.exponential(5)  # Much faster than normal
            timestamp = start_time + timedelta(seconds=time_offset)
            
            source_ip = random.choice(attack_ips)
            method = random.choices(["GET", "POST"], weights=[70, 30])[0]
            path = random.choice(self.attack_paths)
            
            # Server overload patterns
            status_code = random.choices([200, 503, 429, 500, 502], weights=[30, 30, 20, 15, 5])[0]
            response_size = random.randint(100, 5000)  # Smaller due to server stress
            
            # Attack characteristics
            user_agent = random.choice([
                "Mozilla/5.0 (compatible; HttpFloodBot/1.0)",
                "HTTPFlood/2.0",
                random.choice(self.user_agents)  # Some use legitimate UAs
            ])
            
            request_time = random.uniform(0.01, 0.3)  # Very fast requests
            content_length = random.randint(0, 100) if method == "POST" else 0
            
            data.append({
                "timestamp": timestamp,
                "source_ip": source_ip,
                "method": method,
                "path": path,
                "status_code": status_code,
                "response_size": response_size,
                "user_agent": user_agent,
                "request_time": request_time,
                "content_length": content_length,
                "connection_type": "close",  # Often close connections quickly
                "http_version": "HTTP/1.1",
                "attack_type": "http_flood",
                "attack_subtype": "volumetric_flood",
                "label": "malicious"
            })
        
        return data
    
    def generate_slowloris_attack(self, num_requests=200):
        """Generate Slowloris slow HTTP attacks"""
        data = []
        start_time = datetime.now()
        
        # Fewer IPs for Slowloris (connection exhaustion)
        attack_ips = [f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}" 
                     for _ in range(20)]
        
        for i in range(num_requests):
            # Slower initiation but maintains connections
            time_offset = np.random.exponential(30)
            timestamp = start_time + timedelta(seconds=time_offset)
            
            source_ip = random.choice(attack_ips)
            method = "GET"  # Slowloris typically uses GET
            path = random.choice(["/", "/index.html", "/login"])
            
            # Incomplete requests or timeouts
            status_code = random.choices([408, 400, 200, 503], weights=[40, 25, 20, 15])[0]
            response_size = random.randint(0, 1000)  # Very small or no response
            
            user_agent = random.choice([
                "SlowHTTPTest",
                "Slowloris/2.0",
                random.choice(self.user_agents)
            ])
            
            # Very slow requests (connection held open)
            request_time = random.uniform(10.0, 300.0)  # 10 seconds to 5 minutes
            content_length = 0
            
            data.append({
                "timestamp": timestamp,
                "source_ip": source_ip,
                "method": method,
                "path": path,
                "status_code": status_code,
                "response_size": response_size,
                "user_agent": user_agent,
                "request_time": request_time,
                "content_length": content_length,
                "connection_type": "keep-alive",  # Keeps connections open
                "http_version": "HTTP/1.1",
                "attack_type": "slowloris",
                "attack_subtype": "slow_headers",
                "label": "malicious"
            })
        
        return data
    
    def generate_slow_post_attack(self, num_requests=150):
        """Generate Slow POST attacks (R.U.D.Y - Are You Dead Yet)"""
        data = []
        start_time = datetime.now()
        
        attack_ips = [f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}" 
                     for _ in range(15)]
        
        for i in range(num_requests):
            time_offset = np.random.exponential(45)
            timestamp = start_time + timedelta(seconds=time_offset)
            
            source_ip = random.choice(attack_ips)
            method = "POST"
            path = random.choice(["/login", "/contact", "/upload", "/api/submit"])
            
            # POST attacks often cause timeouts
            status_code = random.choices([408, 413, 400, 200, 503], weights=[35, 20, 20, 15, 10])[0]
            response_size = random.randint(100, 3000)
            
            user_agent = random.choice([
                "R.U.D.Y./2.0",
                "SlowPOST/1.0",
                random.choice(self.user_agents)
            ])
            
            # Slow POST with large content
            request_time = random.uniform(30.0, 600.0)  # Very slow
            content_length = random.randint(1000000, 10000000)  # Large POST data
            
            data.append({
                "timestamp": timestamp,
                "source_ip": source_ip,
                "method": method,
                "path": path,
                "status_code": status_code,
                "response_size": response_size,
                "user_agent": user_agent,
                "request_time": request_time,
                "content_length": content_length,
                "connection_type": "keep-alive",
                "http_version": "HTTP/1.1",
                "attack_type": "slow_post",
                "attack_subtype": "slow_body",
                "label": "malicious"
            })
        
        return data
    
    def generate_http_desync_attack(self, num_requests=100):
        """Generate HTTP Request Smuggling/Desync attacks"""
        data = []
        start_time = datetime.now()
        
        attack_ips = [f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}" 
                     for _ in range(10)]
        
        for i in range(num_requests):
            time_offset = np.random.exponential(60)
            timestamp = start_time + timedelta(seconds=time_offset)
            
            source_ip = random.choice(attack_ips)
            method = random.choices(["POST", "GET"], weights=[80, 20])[0]
            path = random.choice(["/api/submit", "/upload", "/proxy"])
            
            # Desync attacks often cause server errors
            status_code = random.choices([400, 500, 502, 200], weights=[40, 30, 20, 10])[0]
            response_size = random.randint(200, 5000)
            
            user_agent = random.choice([
                "HTTPDesync/1.0",
                "RequestSmuggler/2.0",
                random.choice(self.user_agents)
            ])
            
            request_time = random.uniform(0.5, 5.0)
            # Conflicting content lengths (CL.TE or TE.CL)
            content_length = random.randint(100, 1000) if method == "POST" else 0
            
            data.append({
                "timestamp": timestamp,
                "source_ip": source_ip,
                "method": method,
                "path": path,
                "status_code": status_code,
                "response_size": response_size,
                "user_agent": user_agent,
                "request_time": request_time,
                "content_length": content_length,
                "connection_type": "keep-alive",
                "http_version": random.choice(["HTTP/1.1", "HTTP/2.0"]),
                "attack_type": "http_desync",
                "attack_subtype": "request_smuggling",
                "label": "malicious"
            })
        
        return data
    
    def generate_range_header_attack(self, num_requests=80):
        """Generate Range Header DoS attacks"""
        data = []
        start_time = datetime.now()
        
        attack_ips = [f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}" 
                     for _ in range(8)]
        
        for i in range(num_requests):
            time_offset = np.random.exponential(20)
            timestamp = start_time + timedelta(seconds=time_offset)
            
            source_ip = random.choice(attack_ips)
            method = "GET"
            path = random.choice(["/download/largefile.pdf", "/video/stream.mp4", "/images/bigimage.jpg"])
            
            # Range attacks often overload servers
            status_code = random.choices([206, 416, 503, 500], weights=[30, 25, 25, 20])[0]
            response_size = random.randint(1000, 50000)  # Partial content
            
            user_agent = random.choice([
                "RangeAttacker/1.0",
                "ByteRangeDoS/2.0",
                random.choice(self.user_agents)
            ])
            
            request_time = random.uniform(2.0, 30.0)  # Server processing multiple ranges
            content_length = 0
            
            data.append({
                "timestamp": timestamp,
                "source_ip": source_ip,
                "method": method,
                "path": path,
                "status_code": status_code,
                "response_size": response_size,
                "user_agent": user_agent,
                "request_time": request_time,
                "content_length": content_length,
                "connection_type": "close",
                "http_version": "HTTP/1.1",
                "attack_type": "range_header",
                "attack_subtype": "byte_range_dos",
                "label": "malicious"
            })
        
        return data
    
    def generate_http_pipeline_attack(self, num_requests=120):
        """Generate HTTP Pipelining abuse attacks"""
        data = []
        start_time = datetime.now()
        
        attack_ips = [f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}" 
                     for _ in range(12)]
        
        for i in range(num_requests):
            time_offset = np.random.exponential(10)
            timestamp = start_time + timedelta(seconds=time_offset)
            
            source_ip = random.choice(attack_ips)
            method = "GET"
            path = random.choice(self.attack_paths)
            
            # Pipeline attacks can cause server confusion
            status_code = random.choices([200, 400, 502, 503], weights=[40, 25, 20, 15])[0]
            response_size = random.randint(500, 8000)
            
            user_agent = random.choice([
                "PipelineFlood/1.0",
                "HTTPPipeline/2.0",
                random.choice(self.user_agents)
            ])
            
            request_time = random.uniform(0.1, 2.0)
            content_length = 0
            
            data.append({
                "timestamp": timestamp,
                "source_ip": source_ip,
                "method": method,
                "path": path,
                "status_code": status_code,
                "response_size": response_size,
                "user_agent": user_agent,
                "request_time": request_time,
                "content_length": content_length,
                "connection_type": "keep-alive",
                "http_version": "HTTP/1.1",  # Pipelining is HTTP/1.1 specific
                "attack_type": "http_pipeline",
                "attack_subtype": "pipeline_abuse",
                "label": "malicious"
            })
        
        return data
    
    def generate_comprehensive_http_dataset(self, total_requests=5000):
        """Generate comprehensive HTTP attack dataset"""
        print("Generating comprehensive HTTP protocol attack dataset...")
        
        # Distribution of traffic types
        traffic_distribution = {
            'normal': 0.60,           # 60% normal traffic
            'http_flood': 0.16,       # 16% HTTP flood
            'slowloris': 0.08,        # 8% Slowloris
            'slow_post': 0.06,        # 6% Slow POST
            'http_desync': 0.04,      # 4% HTTP desync
            'range_header': 0.03,     # 3% Range header attacks
            'http_pipeline': 0.03     # 3% Pipeline attacks
        }
        
        all_data = []
        
        for attack_type, ratio in traffic_distribution.items():
            num_requests = int(total_requests * ratio)
            print(f"Generating {num_requests} {attack_type} requests...")
            
            if attack_type == 'normal':
                all_data.extend(self.generate_normal_traffic(num_requests))
            elif attack_type == 'http_flood':
                all_data.extend(self.generate_http_flood_attack(num_requests))
            elif attack_type == 'slowloris':
                all_data.extend(self.generate_slowloris_attack(num_requests))
            elif attack_type == 'slow_post':
                all_data.extend(self.generate_slow_post_attack(num_requests))
            elif attack_type == 'http_desync':
                all_data.extend(self.generate_http_desync_attack(num_requests))
            elif attack_type == 'range_header':
                all_data.extend(self.generate_range_header_attack(num_requests))
            elif attack_type == 'http_pipeline':
                all_data.extend(self.generate_http_pipeline_attack(num_requests))
        
        # Convert to DataFrame and shuffle
        df = pd.DataFrame(all_data)
        df = df.sample(frac=1).reset_index(drop=True)
        
        print(f"\nHTTP attack dataset generated with {len(df)} total requests")
        print("\nAttack type distribution:")
        print(df['attack_type'].value_counts())
        print("\nLabel distribution:")
        print(df['label'].value_counts())
        
        return df

# Example usage
if __name__ == "__main__":
    generator = HTTPProtocolAttackGenerator()
    
    # Generate comprehensive HTTP attack dataset
    df = generator.generate_comprehensive_http_dataset(total_requests=10000)
    
    # Save dataset
    df.to_csv('http_protocol_attacks_dataset.csv', index=False)
    print(f"\nDataset saved to 'http_protocol_attacks_dataset.csv'")
    
    # Show detailed statistics
    print("\nDetailed attack statistics:")
    print(df.groupby(['attack_type', 'attack_subtype']).size())
    
    print("\nHTTP-specific features:")
    print("- HTTP methods:", df['method'].unique())
    print("- HTTP versions:", df['http_version'].unique())
    print("- Connection types:", df['connection_type'].unique())
    
    print("\nSample data:")
    print(df[['timestamp', 'source_ip', 'method', 'path', 'status_code', 'attack_type', 'label']].head())