import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler, LabelEncoder, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import warnings
warnings.filterwarnings('ignore')

class HTTPDataProcessor:
    def __init__(self, csv_file):
        """Initialize with the CSV file path"""
        self.csv_file = csv_file
        self.df = None
        self.processed_df = None
        self.scalers = {}
        self.encoders = {}
        
    def load_data(self):
        """Load the dataset from CSV"""
        print("Loading dataset...")
        self.df = pd.read_csv(self.csv_file)
        print(f"Dataset loaded: {self.df.shape[0]:,} rows, {self.df.shape[1]} columns")
        return self.df
    
    def basic_analysis(self):
        """Perform basic exploratory data analysis"""
        print("\n" + "="*60)
        print("BASIC DATA ANALYSIS")
        print("="*60)
        
        # Dataset info
        print(f"Dataset shape: {self.df.shape}")
        print(f"Memory usage: {self.df.memory_usage(deep=True).sum() / 1024 / 1024:.2f} MB")
        
        # Missing values
        print("\nMissing values:")
        missing = self.df.isnull().sum()
        if missing.sum() > 0:
            print(missing[missing > 0])
        else:
            print("No missing values found")
        
        # Data types
        print("\nData types:")
        print(self.df.dtypes)
        
        # Label distribution
        print("\nLabel distribution:")
        label_counts = self.df['label'].value_counts()
        print(label_counts)
        print(f"Class balance: {label_counts.min()/label_counts.max():.3f}")
        
        # Unique values in categorical columns
        categorical_cols = ['method', 'status_category', 'response_size_category', 'label']
        print("\nUnique values in categorical columns:")
        for col in categorical_cols:
            if col in self.df.columns:
                print(f"{col}: {self.df[col].nunique()} unique values")
        
        return self.df.describe()
    
    def visualize_data(self, save_plots=True):
        """Create visualizations of the dataset"""
        print("\n" + "="*60)
        print("DATA VISUALIZATION")
        print("="*60)
        
        # Set up the plotting style
        plt.style.use('default')
        sns.set_palette("husl")
        
        # Create subplots
        fig, axes = plt.subplots(3, 3, figsize=(20, 15))
        fig.suptitle('HTTP Traffic Dataset Analysis', fontsize=16, fontweight='bold')
        
        # 1. Label distribution
        self.df['label'].value_counts().plot(kind='bar', ax=axes[0,0], color=['skyblue', 'salmon'])
        axes[0,0].set_title('Traffic Type Distribution')
        axes[0,0].set_xlabel('Traffic Type')
        axes[0,0].set_ylabel('Count')
        axes[0,0].tick_params(axis='x', rotation=45)
        
        # 2. Status code distribution by label
        status_by_label = pd.crosstab(self.df['label'], self.df['status_code'])
        status_by_label.plot(kind='bar', ax=axes[0,1], stacked=True)
        axes[0,1].set_title('Status Code Distribution by Traffic Type')
        axes[0,1].set_xlabel('Traffic Type')
        axes[0,1].set_ylabel('Count')
        axes[0,1].tick_params(axis='x', rotation=45)
        axes[0,1].legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        
        # 3. HTTP Methods distribution
        method_counts = self.df['method'].value_counts()
        axes[0,2].pie(method_counts.values, labels=method_counts.index, autopct='%1.1f%%')
        axes[0,2].set_title('HTTP Methods Distribution')
        
        # 4. Response size distribution
        self.df.boxplot(column='response_size', by='label', ax=axes[1,0])
        axes[1,0].set_title('Response Size Distribution by Traffic Type')
        axes[1,0].set_xlabel('Traffic Type')
        axes[1,0].set_ylabel('Response Size (bytes)')
        axes[1,0].set_yscale('log')
        
        # 5. Request time distribution
        self.df.boxplot(column='request_time', by='label', ax=axes[1,1])
        axes[1,1].set_title('Request Time Distribution by Traffic Type')
        axes[1,1].set_xlabel('Traffic Type')
        axes[1,1].set_ylabel('Request Time (seconds)')
        axes[1,1].set_yscale('log')
        
        # 6. Requests per minute distribution
        if 'requests_per_minute' in self.df.columns:
            self.df.boxplot(column='requests_per_minute', by='label', ax=axes[1,2])
            axes[1,2].set_title('Requests per Minute by Traffic Type')
            axes[1,2].set_xlabel('Traffic Type')
            axes[1,2].set_ylabel('Requests per Minute')
        else:
            axes[1,2].text(0.5, 0.5, 'Requests per minute\nnot available', 
                          ha='center', va='center', transform=axes[1,2].transAxes)
        
        # 7. Time series plot
        if 'timestamp' in self.df.columns:
            self.df['timestamp'] = pd.to_datetime(self.df['timestamp'])
            time_series = self.df.set_index('timestamp').resample('1min').size()
            time_series.plot(ax=axes[2,0])
            axes[2,0].set_title('Traffic Volume Over Time')
            axes[2,0].set_xlabel('Time')
            axes[2,0].set_ylabel('Requests per Minute')
        
        # 8. User agent length distribution
        if 'user_agent_length' in self.df.columns:
            self.df.boxplot(column='user_agent_length', by='label', ax=axes[2,1])
            axes[2,1].set_title('User Agent Length by Traffic Type')
            axes[2,1].set_xlabel('Traffic Type')
            axes[2,1].set_ylabel('User Agent Length')
        
        # 9. Top source IPs
        top_ips = self.df['source_ip'].value_counts().head(10)
        top_ips.plot(kind='bar', ax=axes[2,2])
        axes[2,2].set_title('Top 10 Source IPs')
        axes[2,2].set_xlabel('Source IP')
        axes[2,2].set_ylabel('Request Count')
        axes[2,2].tick_params(axis='x', rotation=45)
        
        plt.tight_layout()
        
        if save_plots:
            plt.savefig('http_traffic_analysis.png', dpi=300, bbox_inches='tight')
            print("Plots saved as 'http_traffic_analysis.png'")
        
        plt.show()
    
    def feature_engineering(self):
        """Create additional features for machine learning"""
        print("\n" + "="*60)
        print("FEATURE ENGINEERING")
        print("="*60)
        
        # Work on a copy
        self.processed_df = self.df.copy()
        
        # Convert timestamp to datetime if it's not already
        if 'timestamp' in self.processed_df.columns:
            self.processed_df['timestamp'] = pd.to_datetime(self.processed_df['timestamp'])
            
            # Extract time-based features
            self.processed_df['hour'] = self.processed_df['timestamp'].dt.hour
            self.processed_df['day_of_week'] = self.processed_df['timestamp'].dt.dayofweek
            self.processed_df['is_weekend'] = self.processed_df['day_of_week'].isin([5, 6]).astype(int)
            
            # Time-based categorical features
            self.processed_df['time_of_day'] = pd.cut(self.processed_df['hour'], 
                                                    bins=[-1, 6, 12, 18, 24], 
                                                    labels=['night', 'morning', 'afternoon', 'evening'])
        
        # IP-based features
        print("Creating IP-based features...")
        ip_features = self.processed_df.groupby('source_ip').agg({
            'timestamp': 'count',
            'status_code': lambda x: (x >= 400).sum(),
            'response_size': ['mean', 'std'],
            'request_time': ['mean', 'std']
        }).reset_index()
        
        ip_features.columns = ['source_ip', 'ip_request_count', 'ip_error_count', 
                              'ip_avg_response_size', 'ip_std_response_size',
                              'ip_avg_request_time', 'ip_std_request_time']
        
        # Calculate error rate
        ip_features['ip_error_rate'] = ip_features['ip_error_count'] / ip_features['ip_request_count']
        ip_features['ip_error_rate'] = ip_features['ip_error_rate'].fillna(0)
        
        # Merge back to main dataframe
        self.processed_df = self.processed_df.merge(ip_features, on='source_ip', how='left')
        
        # Path-based features
        print("Creating path-based features...")
        self.processed_df['path_length'] = self.processed_df['path'].str.len()
        self.processed_df['path_depth'] = self.processed_df['path'].str.count('/')
        self.processed_df['has_query_params'] = self.processed_df['path'].str.contains('\\?').astype(int)
        self.processed_df['is_api_call'] = self.processed_df['path'].str.contains('/api/').astype(int)
        self.processed_df['is_image'] = self.processed_df['path'].str.contains('\\.(jpg|jpeg|png|gif|svg)$', regex=True).astype(int)
        self.processed_df['is_static'] = self.processed_df['path'].str.contains('\\.(css|js|ico|txt)$', regex=True).astype(int)
        
        # Response size categories
        if 'response_size' in self.processed_df.columns:
            self.processed_df['response_size_log'] = np.log1p(self.processed_df['response_size'])
            self.processed_df['is_large_response'] = (self.processed_df['response_size'] > 100000).astype(int)
        
        # Request timing features
        if 'request_time' in self.processed_df.columns:
            self.processed_df['request_time_log'] = np.log1p(self.processed_df['request_time'])
            self.processed_df['is_slow_request'] = (self.processed_df['request_time'] > 5.0).astype(int)
        
        # User agent features
        if 'user_agent' in self.processed_df.columns:
            self.processed_df['ua_is_mobile'] = self.processed_df['user_agent'].str.contains('Mobile|Android|iPhone', regex=True).astype(int)
            self.processed_df['ua_is_bot'] = self.processed_df['user_agent'].str.contains('bot|Bot|spider|crawler', regex=True).astype(int)
            self.processed_df['ua_is_suspicious'] = self.processed_df['user_agent'].str.contains('attack|ddos|flood|Anonymous', regex=True).astype(int)
        
        # Session-based features
        if 'requests_per_session' in self.processed_df.columns:
            self.processed_df['is_high_session_activity'] = (self.processed_df['requests_per_session'] > 50).astype(int)
        
        print(f"Feature engineering complete. New shape: {self.processed_df.shape}")
        print(f"Added {self.processed_df.shape[1] - self.df.shape[1]} new features")
        
        return self.processed_df
    
    def prepare_for_ml(self, target_column='label', test_size=0.2, random_state=42):
        """Prepare data for machine learning"""
        print("\n" + "="*60)
        print("PREPARING DATA FOR MACHINE LEARNING")
        print("="*60)
        
        if self.processed_df is None:
            print("Running feature engineering first...")
            self.feature_engineering()
        
        # Separate features and target
        X = self.processed_df.drop([target_column], axis=1)
        y = self.processed_df[target_column]
        
        # Remove non-numeric columns that shouldn't be used for ML
        non_ml_columns = ['timestamp', 'source_ip', 'path', 'user_agent', 'session_id']
        X_ml = X.drop([col for col in non_ml_columns if col in X.columns], axis=1)
        
        # Handle categorical variables
        categorical_columns = X_ml.select_dtypes(include=['object', 'category']).columns
        
        print(f"Encoding {len(categorical_columns)} categorical columns...")
        for col in categorical_columns:
            le = LabelEncoder()
            X_ml[col] = le.fit_transform(X_ml[col].astype(str))
            self.encoders[col] = le
        
        # Handle missing values
        X_ml = X_ml.fillna(X_ml.median())
        
        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(
            X_ml, y, test_size=test_size, random_state=random_state, stratify=y
        )
        
        # Scale the features
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # Convert back to DataFrames
        X_train_scaled = pd.DataFrame(X_train_scaled, columns=X_train.columns, index=X_train.index)
        X_test_scaled = pd.DataFrame(X_test_scaled, columns=X_test.columns, index=X_test.index)
        
        self.scalers['standard'] = scaler
        
        print(f"Training set: {X_train_scaled.shape}")
        print(f"Test set: {X_test_scaled.shape}")
        print(f"Features: {X_train_scaled.shape[1]}")
        
        return X_train_scaled, X_test_scaled, y_train, y_test, X_ml.columns.tolist()
    
    def quick_model_evaluation(self, X_train, X_test, y_train, y_test, feature_names):
        """Quick model evaluation with Random Forest"""
        print("\n" + "="*60)
        print("QUICK MODEL EVALUATION")
        print("="*60)
        
        # Train Random Forest
        print("Training Random Forest classifier...")
        rf = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
        rf.fit(X_train, y_train)
        
        # Predictions
        y_pred = rf.predict(X_test)
        
        # Classification report
        print("\nClassification Report:")
        print(classification_report(y_test, y_pred))
        
        # Feature importance
        print("\nTop 10 Most Important Features:")
        feature_importance = pd.DataFrame({
            'feature': feature_names,
            'importance': rf.feature_importances_
        }).sort_values('importance', ascending=False)
        
        print(feature_importance.head(10))
        
        # Confusion matrix
        cm = confusion_matrix(y_test, y_pred)
        
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=['Normal', 'DDoS'], yticklabels=['Normal', 'DDoS'])
        plt.title('Confusion Matrix')
        plt.ylabel('Actual')
        plt.xlabel('Predicted')
        plt.tight_layout()
        plt.savefig('confusion_matrix.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        return rf, feature_importance
    
    def generate_report(self, output_file='data_processing_report.txt'):
        """Generate a comprehensive data processing report"""
        print("\n" + "="*60)
        print("GENERATING COMPREHENSIVE REPORT")
        print("="*60)
        
        with open(output_file, 'w') as f:
            f.write("HTTP TRAFFIC DATASET PROCESSING REPORT\n")
            f.write("="*50 + "\n\n")
            
            # Basic info
            f.write(f"Dataset: {self.csv_file}\n")
            f.write(f"Original shape: {self.df.shape}\n")
            if self.processed_df is not None:
                f.write(f"Processed shape: {self.processed_df.shape}\n")
            f.write(f"Memory usage: {self.df.memory_usage(deep=True).sum() / 1024 / 1024:.2f} MB\n\n")
            
            # Label distribution
            f.write("LABEL DISTRIBUTION:\n")
            label_counts = self.df['label'].value_counts()
            for label, count in label_counts.items():
                f.write(f"{label}: {count:,} ({count/len(self.df)*100:.1f}%)\n")
            f.write(f"Class balance ratio: {label_counts.min()/label_counts.max():.3f}\n\n")
            
            # Feature summary
            f.write("FEATURE SUMMARY:\n")
            numeric_cols = self.df.select_dtypes(include=[np.number]).columns
            for col in numeric_cols:
                if col != 'label':
                    f.write(f"{col}:\n")
                    f.write(f"  Mean: {self.df[col].mean():.3f}\n")
                    f.write(f"  Std: {self.df[col].std():.3f}\n")
                    f.write(f"  Min: {self.df[col].min():.3f}\n")
                    f.write(f"  Max: {self.df[col].max():.3f}\n\n")
            
            # Top values for categorical columns
            categorical_cols = ['method', 'status_code', 'source_ip']
            for col in categorical_cols:
                if col in self.df.columns:
                    f.write(f"TOP {col.upper()}:\n")
                    top_values = self.df[col].value_counts().head(5)
                    for value, count in top_values.items():
                        f.write(f"  {value}: {count:,}\n")
                    f.write("\n")
        
        print(f"Report saved to '{output_file}'")
        
    def export_processed_data(self, filename='processed_http_traffic.csv'):
        """Export the processed dataset"""
        if self.processed_df is not None:
            self.processed_df.to_csv(filename, index=False)
            print(f"Processed dataset exported to '{filename}'")
        else:
            print("No processed data available. Run feature_engineering() first.")

# Example usage
if __name__ == "__main__":
    # Initialize processor
    processor = HTTPDataProcessor('large_http_traffic_dataset_100k.csv')
    
    # Load and analyze data
    df = processor.load_data()
    
    # Basic analysis
    basic_stats = processor.basic_analysis()
    
    # Visualizations
    processor.visualize_data(save_plots=True)
    
    # Feature engineering
    processed_df = processor.feature_engineering()
    
    # Prepare for ML
    X_train, X_test, y_train, y_test, feature_names = processor.prepare_for_ml()
    
    # Quick model evaluation
    model, feature_importance = processor.quick_model_evaluation(
        X_train, X_test, y_train, y_test, feature_names
    )
    
    # Generate report
    processor.generate_report()
    
    # Export processed data
    processor.export_processed_data()
    
    print("\n" + "="*60)
    print("DATA PROCESSING COMPLETE!")
    print("="*60)
    print("Files generated:")
    print("- http_traffic_analysis.png (visualizations)")
    print("- confusion_matrix.png (model evaluation)")
    print("- data_processing_report.txt (comprehensive report)")
    print("- processed_http_traffic.csv (processed dataset)")