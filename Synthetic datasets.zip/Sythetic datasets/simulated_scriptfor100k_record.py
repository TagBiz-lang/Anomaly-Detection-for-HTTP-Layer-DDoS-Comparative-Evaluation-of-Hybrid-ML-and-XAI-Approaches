import random
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import time
from collections import defaultdict

class LargeHTTPTrafficGenerator:
    def __init__(self):
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.2 Mobile/15E148 Safari/604.1",
            "Mozilla/5.0 (Android 11; Mobile; rv:91.0) Gecko/91.0 Firefox/91.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:91.0) Gecko/20100101 Firefox/91.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:91.0) Gecko/20100101 Firefox/91.0",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Edge/91.0.864.59"
        ]
        
        self.http_methods = ["GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS", "PATCH"]
        self.status_codes = {
            'success': [200, 201, 202, 204],
            'redirect': [301, 302, 304, 307, 308],
            'client_error': [400, 401, 403, 404, 405, 409, 410, 422, 429],
            'server_error': [500, 501, 502, 503, 504, 507]
        }
        
        self.content_types = [
            "text/html", "application/json", "text/css", "application/javascript",
            "image/jpeg", "image/png", "image/gif", "text/plain", "application/xml",
            "application/pdf", "video/mp4", "audio/mpeg"
        ]
        
        self.normal_paths = [
            "/", "/index.html", "/home", "/about", "/contact", "/products", "/services",
            "/api/users", "/api/products", "/api/orders", "/api/auth", "/api/search",
            "/images/logo.png", "/images/banner.jpg", "/css/style.css", "/css/bootstrap.min.css",
            "/js/main.js", "/js/jquery.min.js", "/login", "/logout", "/register",
            "/dashboard", "/profile", "/settings", "/help", "/faq", "/blog",
            "/news", "/events", "/gallery", "/download", "/upload", "/search"
        ]
        
        # Pre-generate IP pools for efficiency
        self.normal_ip_pool = self._generate_ip_pool(1000, clustered=False)
        self.attack_ip_pool = self._generate_ip_pool(200, clustered=True)
        
    def _generate_ip_pool(self, size, clustered=False):
        """Pre-generate IP address pools for better performance"""
        ips = []
        if clustered:
            # Generate botnet-like IPs with some clustering
            subnets = [f"192.168.{i}" for i in range(1, 20)]
            subnets.extend([f"10.0.{i}" for i in range(1, 20)])
            subnets.extend([f"172.16.{i}" for i in range(1, 20)])
            
            for _ in range(size):
                if random.random() < 0.4:  # 40% clustered
                    subnet = random.choice(subnets)
                    ips.append(f"{subnet}.{random.randint(1, 254)}")
                else:
                    ips.append(f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}")
        else:
            # Normal diverse IPs
            for _ in range(size):
                ips.append(f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}")
        
        return ips
    
    def generate_batch_normal_traffic(self, num_requests=50000, duration_hours=24):
        """Generate normal HTTP traffic in batches for better performance"""
        print(f"Generating {num_requests} normal traffic records...")
        
        # Pre-allocate arrays for better performance
        timestamps = []
        source_ips = []
        methods = []
        paths = []
        status_codes = []
        response_sizes = []
        user_agents = []
        request_times = []
        session_ids = []
        requests_per_session = []
        
        start_time = datetime.now()
        duration_seconds = duration_hours * 3600
        
        # Generate realistic session patterns
        active_sessions = {}
        session_counter = 0
        
        # Method and status code weights for normal traffic
        method_weights = [0.70, 0.20, 0.05, 0.02, 0.015, 0.01, 0.005]  # GET, POST, PUT, DELETE, HEAD, OPTIONS, PATCH
        status_weights = [0.85, 0.08, 0.05, 0.02]  # success, redirect, client_error, server_error
        
        for i in range(num_requests):
            if i % 10000 == 0:
                print(f"Generated {i} normal records...")
            
            # Time distribution - follow realistic daily patterns
            time_offset = np.random.exponential(duration_seconds / num_requests)
            # Add some daily pattern variation
            hour_factor = 1 + 0.5 * np.sin(2 * np.pi * time_offset / 86400)  # 24-hour cycle
            timestamp = start_time + timedelta(seconds=time_offset * hour_factor)
            
            # Session management
            if random.random() < 0.05 or len(active_sessions) == 0:  # 5% chance of new session
                session_counter += 1
                session_id = f"normal_session_{session_counter}"
                client_ip = random.choice(self.normal_ip_pool)
                user_agent = random.choice(self.user_agents)
                active_sessions[session_id] = {
                    "ip": client_ip,
                    "user_agent": user_agent,
                    "requests": 0,
                    "created": timestamp
                }
            
            # Choose random active session
            session_id = random.choice(list(active_sessions.keys()))
            session = active_sessions[session_id]
            session["requests"] += 1
            
            # Normal request characteristics
            method = np.random.choice(self.http_methods, p=method_weights)
            path = random.choice(self.normal_paths)
            
            # Status code based on realistic distribution
            status_category = np.random.choice(['success', 'redirect', 'client_error', 'server_error'], 
                                             p=status_weights)
            status_code = random.choice(self.status_codes[status_category])
            
            # Response size based on content type and path
            if any(ext in path for ext in ['.png', '.jpg', '.jpeg', '.gif', '.mp4']):
                response_size = int(np.random.lognormal(12, 1))  # Large files
            elif any(ext in path for ext in ['.css', '.js']):
                response_size = int(np.random.lognormal(8, 1))   # Medium files
            else:
                response_size = int(np.random.lognormal(6, 1))   # Small files
            
            # Realistic request timing
            request_time = np.random.gamma(2, 0.5)  # Gamma distribution for response times
            
            # Store data
            timestamps.append(timestamp)
            source_ips.append(session["ip"])
            methods.append(method)
            paths.append(path)
            status_codes.append(status_code)
            response_sizes.append(response_size)
            user_agents.append(session["user_agent"])
            request_times.append(request_time)
            session_ids.append(session_id)
            requests_per_session.append(session["requests"])
            
            # Clean up old sessions
            if session["requests"] > random.randint(20, 100):
                del active_sessions[session_id]
        
        # Create DataFrame
        data = {
            'timestamp': timestamps,
            'source_ip': source_ips,
            'method': methods,
            'path': paths,
            'status_code': status_codes,
            'response_size': response_sizes,
            'user_agent': user_agents,
            'request_time': request_times,
            'session_id': session_ids,
            'requests_per_session': requests_per_session,
            'label': ['normal'] * num_requests
        }
        
        print(f"Completed generating {num_requests} normal records")
        return pd.DataFrame(data)
    
    def generate_batch_ddos_traffic(self, num_requests=50000, duration_hours=2):
        """Generate DDoS attack traffic in batches"""
        print(f"Generating {num_requests} DDoS attack records...")
        
        # Pre-allocate arrays
        timestamps = []
        source_ips = []
        methods = []
        paths = []
        status_codes = []
        response_sizes = []
        user_agents = []
        request_times = []
        session_ids = []
        requests_per_session = []
        
        start_time = datetime.now()
        duration_seconds = duration_hours * 3600
        
        # Attack characteristics
        attack_paths = ["/", "/login", "/api/heavy_endpoint", "/download/largefile.zip", 
                       "/api/auth", "/search", "/api/users", "/admin"]
        
        # Simulate different attack types
        attack_types = {
            'volumetric': 0.4,    # High volume requests
            'slowloris': 0.2,     # Slow requests
            'http_flood': 0.3,    # HTTP GET/POST flood
            'mixed': 0.1          # Mixed attack
        }
        
        # Method and status weights for attacks
        method_weights = [0.60, 0.35, 0.03, 0.01, 0.005, 0.003, 0.002]
        status_weights = [0.25, 0.05, 0.30, 0.40]  # More errors during attacks
        
        for i in range(num_requests):
            if i % 10000 == 0:
                print(f"Generated {i} DDoS records...")
            
            # Much higher frequency attacks
            time_offset = np.random.exponential(duration_seconds / num_requests / 10)  # 10x faster
            timestamp = start_time + timedelta(seconds=time_offset)
            
            # Attack IP selection (more repetition)
            source_ip = random.choice(self.attack_ip_pool)
            
            # Determine attack type for this request
            attack_type = np.random.choice(list(attack_types.keys()), p=list(attack_types.values()))
            
            # Attack-specific characteristics
            if attack_type == 'volumetric':
                method = np.random.choice(['GET', 'POST'], p=[0.8, 0.2])
                path = random.choice(attack_paths[:4])  # Target main endpoints
                request_time = np.random.exponential(0.1)  # Very fast requests
                
            elif attack_type == 'slowloris':
                method = 'GET'
                path = random.choice(attack_paths)
                request_time = np.random.exponential(30)  # Very slow requests
                
            elif attack_type == 'http_flood':
                method = np.random.choice(['GET', 'POST'], p=[0.7, 0.3])
                path = random.choice(attack_paths)
                request_time = np.random.exponential(0.5)
                
            else:  # mixed
                method = np.random.choice(self.http_methods, p=method_weights)
                path = random.choice(attack_paths)
                request_time = np.random.exponential(1.0)
            
            # Status codes - more errors during attacks
            status_category = np.random.choice(['success', 'redirect', 'client_error', 'server_error'], 
                                             p=status_weights)
            status_code = random.choice(self.status_codes[status_category])
            
            # Response sizes - typically smaller due to server stress
            response_size = int(np.random.lognormal(5, 1))  # Smaller responses
            
            # Malicious or repeated user agents
            if random.random() < 0.4:
                user_agent = random.choice(self.user_agents)
            else:
                user_agent = random.choice(["AttackBot/1.0", "DDoSBot/2.0", "HttpFlood/1.0", 
                                          "BotNet/3.0", "Anonymous"])
            
            # Fake session management for attacks
            session_id = f"attack_session_{i % 500}"  # Reuse session IDs
            requests_in_session = random.randint(100, 1000)  # Very high per session
            
            # Store data
            timestamps.append(timestamp)
            source_ips.append(source_ip)
            methods.append(method)
            paths.append(path)
            status_codes.append(status_code)
            response_sizes.append(response_size)
            user_agents.append(user_agent)
            request_times.append(request_time)
            session_ids.append(session_id)
            requests_per_session.append(requests_in_session)
        
        # Create DataFrame
        data = {
            'timestamp': timestamps,
            'source_ip': source_ips,
            'method': methods,
            'path': paths,
            'status_code': status_codes,
            'response_size': response_sizes,
            'user_agent': user_agents,
            'request_time': request_times,
            'session_id': session_ids,
            'requests_per_session': requests_per_session,
            'label': ['ddos'] * num_requests
        }
        
        print(f"Completed generating {num_requests} DDoS records")
        return pd.DataFrame(data)
    
    def generate_large_dataset(self, total_records=100000, ddos_ratio=0.3):
        """Generate a large mixed dataset"""
        ddos_records = int(total_records * ddos_ratio)
        normal_records = total_records - ddos_records
        
        print(f"Generating large dataset with {total_records} records")
        print(f"Normal records: {normal_records}")
        print(f"DDoS records: {ddos_records}")
        
        # Generate datasets
        normal_df = self.generate_batch_normal_traffic(normal_records)
        ddos_df = self.generate_batch_ddos_traffic(ddos_records)
        
        # Combine datasets
        print("Combining datasets...")
        combined_df = pd.concat([normal_df, ddos_df], ignore_index=True)
        
        # Shuffle the data
        print("Shuffling data...")
        combined_df = combined_df.sample(frac=1).reset_index(drop=True)
        
        return combined_df
    
    def add_advanced_features(self, df):
        """Add advanced features for large datasets"""
        print("Adding advanced features...")
        
        # Convert timestamp to datetime
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Time-based features
        df['hour'] = df['timestamp'].dt.hour
        df['day_of_week'] = df['timestamp'].dt.dayofweek
        df['minute'] = df['timestamp'].dt.floor('min')
        
        print("Computing request rate features...")
        # Request rate features (more efficient for large datasets)
        request_rates = df.groupby(['source_ip', 'minute']).size().reset_index(name='requests_per_minute')
        df = df.merge(request_rates, on=['source_ip', 'minute'], how='left')
        
        # Response size categories
        df['response_size_category'] = pd.cut(df['response_size'], 
                                            bins=[0, 1000, 10000, 100000, 1000000, float('inf')],
                                            labels=['tiny', 'small', 'medium', 'large', 'huge'])
        
        # Status code categories
        df['status_category'] = df['status_code'].apply(
            lambda x: 'success' if x < 300 else 'redirect' if x < 400 else 'client_error' if x < 500 else 'server_error'
        )
        
        # User agent analysis
        df['user_agent_length'] = df['user_agent'].str.len()
        df['is_bot'] = df['user_agent'].str.contains('bot|Bot|crawler|spider|attack|ddos|flood', case=False, na=False)
        
        # IP-based features
        print("Computing IP-based features...")
        ip_stats = df.groupby('source_ip').agg({
            'timestamp': ['count', 'min', 'max'],
            'status_code': lambda x: (x >= 400).sum(),
            'response_size': 'mean'
        }).reset_index()
        
        ip_stats.columns = ['source_ip', 'total_requests', 'first_request', 'last_request', 'error_count', 'avg_response_size']
        ip_stats['request_duration'] = (ip_stats['last_request'] - ip_stats['first_request']).dt.total_seconds()
        ip_stats['error_rate'] = ip_stats['error_count'] / ip_stats['total_requests']
        
        df = df.merge(ip_stats[['source_ip', 'total_requests', 'request_duration', 'error_rate']], 
                     on='source_ip', how='left')
        
        return df

# Example usage for 100K records
if __name__ == "__main__":
    generator = LargeHTTPTrafficGenerator()
    
    # Generate 100K dataset
    print("=" * 50)
    print("LARGE SCALE HTTP TRAFFIC GENERATOR")
    print("=" * 50)
    
    start_time = time.time()
    
    # Generate the dataset
    df = generator.generate_large_dataset(total_records=100000, ddos_ratio=0.3)
    
    # Add advanced features
    df = generator.add_advanced_features(df)
    
    generation_time = time.time() - start_time
    
    # Display statistics
    print("\n" + "=" * 50)
    print("DATASET STATISTICS")
    print("=" * 50)
    print(f"Total records: {len(df):,}")
    print(f"Generation time: {generation_time:.2f} seconds")
    print(f"Records per second: {len(df)/generation_time:.0f}")
    print(f"\nLabel distribution:")
    print(df['label'].value_counts())
    print(f"\nUnique IPs: {df['source_ip'].nunique():,}")
    print(f"Time range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    print(f"Dataset memory usage: {df.memory_usage(deep=True).sum() / 1024 / 1024:.2f} MB")
    
    # Show feature info
    print(f"\nDataset shape: {df.shape}")
    print(f"Features: {list(df.columns)}")
    
    # Save to CSV
    print("\nSaving dataset...")
    df.to_csv('large_http_traffic_dataset_100k.csv', index=False)
    print("Dataset saved to 'large_http_traffic_dataset_100k.csv'")
    
    # Show sample data
    print("\nSample data:")
    print(df.head())
    
    print("\n" + "=" * 50)
    print("GENERATION COMPLETE!")
    print("=" * 50)