import random
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import time
import ipaddress

class HTTPTrafficGenerator:
    def __init__(self):
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X)",
            "Mozilla/5.0 (Android 11; Mobile; rv:91.0) Gecko/91.0"
        ]
        
        self.http_methods = ["GET", "POST", "PUT", "DELETE", "HEAD", "OPTIONS"]
        self.status_codes = [200, 201, 204, 301, 302, 304, 400, 401, 403, 404, 500, 502, 503]
        self.content_types = [
            "text/html", "application/json", "text/css", "application/javascript",
            "image/jpeg", "image/png", "image/gif", "text/plain"
        ]
        
        self.normal_paths = [
            "/", "/index.html", "/about", "/contact", "/products", "/services",
            "/api/users", "/api/products", "/images/logo.png", "/css/style.css",
            "/js/main.js", "/login", "/logout", "/dashboard", "/profile"
        ]
        
    def generate_ip_address(self, attack_mode=False):
        """Generate IP addresses - more diverse for normal, clustered for attacks"""
        if attack_mode:
            # Simulate botnet - some IPs from similar subnets
            if random.random() < 0.3:  # 30% chance of clustered IPs
                base_ip = f"192.168.{random.randint(1, 254)}"
                return f"{base_ip}.{random.randint(1, 254)}"
            else:
                # Random IPs but some repetition
                return f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
        else:
            # Normal traffic - more diverse IP distribution
            return f"{random.randint(1, 223)}.{random.randint(1, 254)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
    
    def generate_normal_traffic(self, num_requests=1000, duration_minutes=60):
        """Generate normal HTTP traffic patterns"""
        data = []
        start_time = datetime.now()
        
        # Create session-like behavior
        sessions = {}
        session_count = num_requests // 10  # Average 10 requests per session
        
        for i in range(num_requests):
            # Time distribution - more traffic during business hours
            time_offset = np.random.exponential(duration_minutes * 60 / num_requests)
            timestamp = start_time + timedelta(seconds=time_offset)
            
            # Session management
            if random.random() < 0.1 or not sessions:  # 10% chance of new session
                session_id = f"session_{len(sessions)}"
                client_ip = self.generate_ip_address()
                user_agent = random.choice(self.user_agents)
                sessions[session_id] = {"ip": client_ip, "user_agent": user_agent, "requests": 0}
            
            session_id = random.choice(list(sessions.keys()))
            session = sessions[session_id]
            session["requests"] += 1
            
            # Normal request characteristics
            method = random.choices(["GET", "POST", "PUT", "DELETE"], weights=[70, 20, 5, 5])[0]
            path = random.choice(self.normal_paths)
            status_code = random.choices([200, 404, 500, 301], weights=[85, 10, 3, 2])[0]
            
            # Response size based on content type
            if path.endswith(('.png', '.jpg', '.jpeg', '.gif')):
                response_size = random.randint(5000, 500000)  # Images
            elif path.endswith(('.css', '.js')):
                response_size = random.randint(1000, 50000)   # Static files
            else:
                response_size = random.randint(500, 10000)    # HTML/JSON
            
            # Request timing - normal human-like intervals
            request_time = random.uniform(0.1, 2.0)  # Response time in seconds
            
            data.append({
                "timestamp": timestamp,
                "source_ip": session["ip"],
                "method": method,
                "path": path,
                "status_code": status_code,
                "response_size": response_size,
                "user_agent": session["user_agent"],
                "request_time": request_time,
                "session_id": session_id,
                "requests_per_session": session["requests"],
                "label": "normal"
            })
            
            # Remove old sessions
            if session["requests"] > 20:  # End session after 20 requests
                del sessions[session_id]
        
        return data
    
    def generate_ddos_traffic(self, num_requests=5000, duration_minutes=10):
        """Generate DDoS attack traffic patterns"""
        data = []
        start_time = datetime.now()
        
        # Attack characteristics
        attack_ips = [self.generate_ip_address(attack_mode=True) for _ in range(num_requests // 100)]
        attack_paths = ["/", "/login", "/api/heavy_endpoint", "/download/largefile.zip"]
        
        for i in range(num_requests):
            # High frequency - much shorter intervals
            time_offset = np.random.exponential(duration_minutes * 60 / num_requests)
            timestamp = start_time + timedelta(seconds=time_offset)
            
            # DDoS characteristics
            source_ip = random.choice(attack_ips)  # Repeated IPs
            method = random.choices(["GET", "POST"], weights=[80, 20])[0]
            path = random.choice(attack_paths)
            
            # Attack patterns
            status_code = random.choices([200, 503, 429, 500], weights=[30, 40, 20, 10])[0]
            response_size = random.randint(100, 5000)  # Smaller responses due to server stress
            
            # Malicious user agents or repeated ones
            if random.random() < 0.3:
                user_agent = random.choice(self.user_agents)
            else:
                user_agent = "AttackBot/1.0"
            
            # Fast request timing
            request_time = random.uniform(0.01, 0.5)  # Much faster requests
            
            data.append({
                "timestamp": timestamp,
                "source_ip": source_ip,
                "method": method,
                "path": path,
                "status_code": status_code,
                "response_size": response_size,
                "user_agent": user_agent,
                "request_time": request_time,
                "session_id": f"attack_{i % 100}",  # Fake sessions
                "requests_per_session": random.randint(50, 200),  # High requests per session
                "label": "ddos"
            })
        
        return data
    
    def generate_mixed_dataset(self, normal_requests=2000, ddos_requests=1000):
        """Generate a mixed dataset with both normal and attack traffic"""
        print("Generating normal traffic...")
        normal_data = self.generate_normal_traffic(normal_requests)
        
        print("Generating DDoS attack traffic...")
        ddos_data = self.generate_ddos_traffic(ddos_requests)
        
        # Combine and shuffle
        all_data = normal_data + ddos_data
        random.shuffle(all_data)
        
        return pd.DataFrame(all_data)
    
    def add_derived_features(self, df):
        """Add derived features commonly used in DDoS detection"""
        # Convert timestamp to datetime if it's not already
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        
        # Time-based features
        df['hour'] = df['timestamp'].dt.hour
        df['day_of_week'] = df['timestamp'].dt.dayofweek
        
        # Request rate features (requests per minute from same IP)
        df['minute'] = df['timestamp'].dt.floor('T')
        request_rates = df.groupby(['source_ip', 'minute']).size().reset_index(name='requests_per_minute')
        df = df.merge(request_rates, on=['source_ip', 'minute'], how='left')
        
        # Response size statistics
        df['response_size_category'] = pd.cut(df['response_size'], 
                                            bins=[0, 1000, 10000, 100000, float('inf')],
                                            labels=['small', 'medium', 'large', 'very_large'])
        
        # Status code categories
        df['status_category'] = df['status_code'].apply(
            lambda x: 'success' if x < 300 else 'redirect' if x < 400 else 'client_error' if x < 500 else 'server_error'
        )
        
        # User agent diversity (simplified)
        df['user_agent_length'] = df['user_agent'].str.len()
        df['is_bot'] = df['user_agent'].str.contains('bot|Bot|crawler|spider', case=False, na=False)
        
        return df

# Example usage
if __name__ == "__main__":
    generator = HTTPTrafficGenerator()
    
    # Generate mixed dataset
    print("Creating HTTP traffic dataset...")
    df = generator.generate_mixed_dataset(normal_requests=3000, ddos_requests=2000)
    
    # Add derived features
    df = generator.add_derived_features(df)
    
    # Display basic statistics
    print(f"\nDataset created with {len(df)} records")
    print(f"Normal traffic: {len(df[df['label'] == 'normal'])}")
    print(f"DDoS traffic: {len(df[df['label'] == 'ddos'])}")
    print(f"\nUnique IPs: {df['source_ip'].nunique()}")
    print(f"Time range: {df['timestamp'].min()} to {df['timestamp'].max()}")
    
    # Show sample data
    print("\nSample data:")
    print(df.head())
    
    # Save to CSV
    df.to_csv('http_traffic_dataset.csv', index=False)
    print("\nDataset saved to 'http_traffic_dataset.csv'")
    
    # Show feature distributions
    print("\nLabel distribution:")
    print(df['label'].value_counts())
    
    print("\nStatus code distribution by label:")
    print(df.groupby(['label', 'status_code']).size().unstack(fill_value=0))